# ESX Trunk System

A comprehensive trunk storage system for ESX Framework in FiveM.

## Features

- Vehicle-specific trunk storage based on vehicle class
- Weight-based inventory system
- Persistent storage across server restarts
- Security features including vehicle ownership checks
- Lockpicking mechanics for locked vehicles
- Sleek and intuitive UI with search functionality
- Special vehicle support with custom capacities
- Blacklisted items configuration
- Auto-close system for trunks
- Anti-stuck emergency commands
- Inside vehicle access restriction

## Installation

1. Import the SQL file (`install.sql`) to your database
2. Add the resource to your server resources folder
3. Add `ensure esx_trunksystem` to your server.cfg
4. Create the `html/img` folder and add a `default.png` image
5. Restart your server

## Dependencies

- es_extended
- mysql-async

## Configuration

The `config.lua` file allows you to customize various aspects of the system:

- Weight limits for different vehicle classes
- Special vehicles with custom capacities
- Security settings
- Blacklisted items
- Animation settings
- Auto-close settings
- Vehicle access restrictions

## Usage

### Player Commands

- `/opentrunk` - Open the trunk of the nearest vehicle (if close enough)
- `/fixtrunk` - Emergency command to fix UI focus issues
- `/resettrunk` - Complete system reset for troubleshooting
- Alternatively, approach a vehicle's trunk and press the configured key (default: F3)

### Admin Commands

- `/cleartrunk [plate]` - Clear the contents of a vehicle trunk (admin only)

## Creating Item Images

For the inventory UI, place item images in the `html/img/` folder with the item name as the filename (e.g., `bread.png`).

## Emergency Recovery

If you experience any UI issues:
1. Press the BACKSPACE key
2. Use the `/fixtrunk` command
3. For more serious issues, use `/resettrunk`

## Integration with Other Scripts

This resource is designed to integrate with other ESX resources. It provides events and callbacks that can be used by other scripts to interact with the trunk system:

### Server Events

- `esx_trunk:addItem` - Add an item to a trunk
- `esx_trunk:removeItem` - Remove an item from a trunk

### Server Callbacks

- `esx_trunk:getTrunkInventory` - Get the inventory of a trunk
- `esx_trunk:isVehicleOwner` - Check if a player owns a vehicle

## License

This resource is licensed under the GNU General Public License v3.0.

## Credits

Created by [Your Name/Organization]

## Support

For support, please open an issue on GitHub or contact me through Discord.