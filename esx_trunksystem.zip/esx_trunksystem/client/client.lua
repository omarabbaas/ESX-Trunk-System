-- Initialize ESX and variables
ESX = exports["es_extended"]:getSharedObject()

-- Important: Make these variables global (no "local" keyword) so they can be accessed across files
NearVehicle = false
CurrentVehicle = nil
TrunkOpen = false
CurrentDoorIndex = nil -- Track which door index was used for opening

-- Add HasTrunk function directly to client.lua to ensure it's loaded
function HasTrunk(vehicle)
    if not vehicle or not DoesEntityExist(vehicle) then return false end
    
    local vehicleClass = GetVehicleClass(vehicle)
    
    -- Vehicle classes that don't have trunks
    local noTrunkClasses = {
        [8] = true,  -- Motorcycles
        [13] = true, -- Bicycles
        [14] = true, -- Boats
        [15] = true, -- Helicopters
        [16] = true  -- Planes
    }
    
    -- Check if vehicle class has no trunk
    if noTrunkClasses[vehicleClass] then
        return false
    end
    
    return true
end

-- Add GetTrunkPosition function directly as well for safety
function GetTrunkPosition(vehicle)
    if not vehicle or not DoesEntityExist(vehicle) then return nil end
    
    local vehicleModel = GetEntityModel(vehicle)
    local modelName = GetDisplayNameFromVehicleModel(vehicleModel):lower()
    
    -- Get the dimensions of the vehicle
    local min, max = GetModelDimensions(vehicleModel)
    
    -- Default trunk position at the back of the vehicle
    local trunkOffset = vector3(0.0, min.y - 0.5, 0.0)
    
    -- Special trunk positions for specific vehicle models
    local specialPositions = {
        ["panto"] = vector3(0.0, min.y - 0.2, 0.0),      -- Smaller offset for tiny cars
        ["issi2"] = vector3(0.0, min.y - 0.2, 0.0),      -- Smaller offset for tiny cars
        ["journey"] = vector3(0.0, min.y - 1.0, 0.0),    -- Larger offset for RVs
        ["youga"] = vector3(0.0, min.y - 1.0, 0.0),      -- Larger offset for vans
        ["boxville"] = vector3(0.0, min.y - 1.5, 0.0),   -- Larger offset for box trucks
    }
    
    -- Use special position if defined for this model
    if specialPositions[modelName] then
        trunkOffset = specialPositions[modelName]
    end
    
    -- Calculate world position of trunk
    return GetOffsetFromEntityInWorldCoords(vehicle, trunkOffset.x, trunkOffset.y, trunkOffset.z)
end

-- Initialize variables early to prevent nil errors
Citizen.CreateThread(function()
    -- Wait for resource to fully start
    Citizen.Wait(500)
    
    -- Initialize variables with default values
    if NearVehicle == nil then NearVehicle = false end
    if TrunkOpen == nil then TrunkOpen = false end
    
    if Config.Debug then
        print("ESX Trunk System initialized. Variables set up.")
    end
end)

-- Main thread to check if player is near a vehicle trunk
Citizen.CreateThread(function()
    while true do
        local sleep = 1000
        local playerPed = PlayerPedId()
        local coords = GetEntityCoords(playerPed)
        
        -- Check if player is in a vehicle
        local isInVehicle = IsPedInAnyVehicle(playerPed, false)
        
        -- Only check for nearby trunks if player is not in a vehicle or if allowed from inside
        if not isInVehicle or Config.AllowFromInsideVehicle then
            local vehicles = ESX.Game.GetVehiclesInArea(coords, 5.0)
            
            NearVehicle = false
            
            if #vehicles > 0 then
                for i = 1, #vehicles do
                    local vehicle = vehicles[i]
                    
                    -- Skip vehicles without trunks
                    if HasTrunk(vehicle) then
                        -- Get trunk position
                        local trunkPos = GetTrunkPosition(vehicle)
                        
                        if trunkPos then
                            local dist = #(coords - trunkPos)
                            
                            if dist < Config.TrunkDistance then
                                sleep = 5
                                NearVehicle = true
                                CurrentVehicle = vehicle
                                
                                -- Draw marker at trunk position (optional)
                                DrawMarker(20, trunkPos.x, trunkPos.y, trunkPos.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 255, 255, 255, 100, false, true, 2, false, nil, nil, false)
                                
                                -- Display prompt to open trunk
                                local vehicleData = ESX.Game.GetVehicleProperties(vehicle)
                                local plate = vehicleData.plate or "UNKNOWN"
                                ESX.ShowHelpNotification("Press ~INPUT_CONTEXT~ to open trunk [" .. plate .. "]")
                                
                                if IsControlJustReleased(0, 38) then -- E key
                                    if Config.Debug then
                                        print("E key pressed, attempting to open trunk")
                                    end
                                    
                                    -- Check if functions are defined to prevent errors
                                    if OpenTrunk ~= nil then
                                        OpenTrunk(CurrentVehicle)
                                    else
                                        print("ERROR: OpenTrunk function is nil! Check if functions.lua is loaded.")
                                        ESX.ShowNotification("Error: Trunk system not loaded properly. Please report this.")
                                    end
                                end
                                break
                            end
                        end
                    end
                end
            end
        else
            -- Player is in a vehicle, can't access trunk
            NearVehicle = false
            CurrentVehicle = nil
        end
        
        Citizen.Wait(sleep)
    end
end)

-- Thread to auto-close trunk when player moves away
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000) -- Check every second
        
        if Config.AutoCloseEnabled and TrunkOpen and CurrentVehicle and DoesEntityExist(CurrentVehicle) then
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local trunkPos = GetTrunkPosition(CurrentVehicle)
            
            if trunkPos then
                local dist = #(playerCoords - trunkPos)
                
                -- If player moved too far away, close the trunk
                if dist > (Config.TrunkDistance * 1.5) then
                    if Config.Debug then
                        print("Player moved away from trunk, auto-closing", dist)
                    end
                    
                    if CloseTrunk ~= nil then
                        CloseTrunk()
                        
                        if Config.AutoCloseNotify then
                            ESX.ShowNotification("Trunk closed: You moved too far away")
                        end
                    else
                        print("ERROR: CloseTrunk function is nil! Check if functions.lua is loaded.")
                    end
                end
            end
        end
    end
end)

-- Event handler for player entering a vehicle
AddEventHandler('esx:enteredVehicle', function(vehicle, plate, seat)
    -- If trunk is open, close it immediately
    if TrunkOpen then
        if Config.Debug then
            print("Player entered vehicle event, closing trunk")
        end
        
        if CloseTrunk ~= nil then
            CloseTrunk()
        else
            print("ERROR: CloseTrunk function is nil! Check if functions.lua is loaded.")
        end
    end
end)

-- Fallback for when vehicle entry event isn't triggered
Citizen.CreateThread(function()
    local wasInVehicle = false
    
    while true do
        Citizen.Wait(500)
        
        local playerPed = PlayerPedId()
        local isInVehicle = IsPedInAnyVehicle(playerPed, false)
        
        -- Detect when player enters a vehicle
        if isInVehicle and not wasInVehicle then
            if TrunkOpen then
                if Config.Debug then
                    print("Player entered vehicle (fallback detection), closing trunk")
                end
                
                if CloseTrunk ~= nil then
                    CloseTrunk()
                    
                    if Config.AutoCloseNotify then
                        ESX.ShowNotification("Trunk closed: You entered a vehicle")
                    end
                else
                    print("ERROR: CloseTrunk function is nil! Check if functions.lua is loaded.")
                end
            end
        end
        
        wasInVehicle = isInVehicle
    end
end)

-- Thread for player death check
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(500) -- Check frequently
        
        if TrunkOpen then
            local playerPed = PlayerPedId()
            
            -- Check if player is dead
            if IsEntityDead(playerPed) then
                if Config.Debug then
                    print("Player died, closing trunk")
                end
                
                if CloseTrunk ~= nil then
                    CloseTrunk()
                else
                    print("ERROR: CloseTrunk function is nil! Check if functions.lua is loaded.")
                end
            end
        end
    end
end)

-- Basic function skeleton for emergency use
-- Will only be used if the main function in functions.lua fails to load
if OpenTrunk == nil then
    function OpenTrunk(vehicle)
        if not vehicle or not DoesEntityExist(vehicle) then
            ESX.ShowNotification("Error: Vehicle does not exist")
            return
        end
        
        ESX.ShowNotification("Using emergency trunk function - report this issue")
        
        local vehicleData = ESX.Game.GetVehicleProperties(vehicle)
        local plate = vehicleData.plate or "UNKNOWN"
        
        -- Simple trunk open
        local doorIndex = 5
        SetVehicleDoorOpen(vehicle, doorIndex, false, false)
        
        -- Trigger server callback
        ESX.TriggerServerCallback('esx_trunk:getTrunkInventory', function(inventory)
            if inventory then
                -- Send basic UI
                SendNUIMessage({
                    action = "open",
                    inventory = inventory,
                    capacity = 100,
                    plate = plate
                })
                
                -- Set NUI focus
                SetNuiFocus(true, true)
                TrunkOpen = true
                CurrentVehicle = vehicle
                CurrentDoorIndex = doorIndex
            else
                ESX.ShowNotification("You don't have access to this trunk")
                SetVehicleDoorShut(vehicle, doorIndex, false)
            end
        end, plate)
    end
end

if CloseTrunk == nil then
    function CloseTrunk()
        -- Basic close function if main one fails to load
        TrunkOpen = false
        SetNuiFocus(false, false)
        
        if CurrentVehicle and DoesEntityExist(CurrentVehicle) then
            local doorIndex = CurrentDoorIndex or 5
            SetVehicleDoorShut(CurrentVehicle, doorIndex, true)
        end
        
        SendNUIMessage({
            action = "close"
        })
        
        CurrentVehicle = nil
        CurrentDoorIndex = nil
    end
end