-- Register command to open trunk (optional alternative to key press)
RegisterCommand('opentrunk', function()
    -- Check if player is in a vehicle
    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) and not Config.AllowFromInsideVehicle then
        ESX.ShowNotification("You cannot access the trunk from inside a vehicle")
        return
    end
    
    -- Continue with normal trunk opening
    if NearVehicle and CurrentVehicle then
        OpenTrunk(CurrentVehicle)
    else
        ESX.ShowNotification("You need to be near a vehicle trunk")
    end
end, false)

-- Emergency command to fix stuck NUI
RegisterCommand('fixtrunk', function()
    TrunkOpen = false
    CurrentVehicle = nil
    CurrentDoorIndex = nil
    SetNuiFocus(false, false)
    ESX.ShowNotification("UI focus reset")
end, false)

-- Complete reset and refresh of trunk system
RegisterCommand('resettrunk', function()
    -- Reset all variables
    TrunkOpen = false
    NearVehicle = false
    CurrentVehicle = nil
    CurrentDoorIndex = nil

    -- Reset NUI focus
    SetNuiFocus(false, false)
    
    -- Force close any open doors
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    local vehicles = ESX.Game.GetVehiclesInArea(coords, 15.0) -- Check wider area
    
    -- Close trunks of all nearby vehicles
    if #vehicles > 0 then
        for i = 1, #vehicles do
            if DoesEntityExist(vehicles[i]) then
                -- Close all doors, not just trunk
                for j = 0, 7 do
                    SetVehicleDoorShut(vehicles[i], j, true)
                end
            end
        end
    end
    
    -- Send refresh message to UI
    SendNUIMessage({
        action = "forceRefresh"
    })
    
    -- Request clean player data (optional)
    TriggerServerEvent('esx_trunk:requestRefresh')
    
    -- Clear any animations
    ClearPedTasks(playerPed)
    
    -- Show success notification
    ESX.ShowNotification("Trunk system completely reset and refreshed")
    
    -- Log the reset
    TriggerServerEvent('esx_trunk:logReset')
end, false)

-- Debug command to test door indices
RegisterCommand('trunkdoors', function()
    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        
        if vehicle and DoesEntityExist(vehicle) then
            -- Open all doors one by one for testing
            for i = 0, 7 do
                SetVehicleDoorOpen(vehicle, i, false, false)
                ESX.ShowNotification("Opened door index: " .. i)
                Citizen.Wait(1000)
            end
            
            -- Wait a bit then close all doors
            Citizen.Wait(5000)
            for i = 0, 7 do
                SetVehicleDoorShut(vehicle, i, false)
            end
        else
            ESX.ShowNotification("You need to be in a vehicle")
        end
    else
        ESX.ShowNotification("You need to be in a vehicle")
    end
end, false)

-- Register keybinding for trunk opening
RegisterKeyMapping('opentrunk', 'Open Vehicle Trunk', 'keyboard', Config.OpenKey)

-- Debug command to check ownership
RegisterCommand('trunkowner', function()
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    local vehicles = ESX.Game.GetVehiclesInArea(coords, 3.0)
    
    if #vehicles > 0 then
        local vehicle = vehicles[1] -- Get closest vehicle
        if DoesEntityExist(vehicle) then
            local vehicleData = ESX.Game.GetVehicleProperties(vehicle)
            if vehicleData and vehicleData.plate then
                ESX.ShowNotification("Checking ownership for plate: " .. vehicleData.plate)
                
                -- Debug ownership check
                DebugVehicleOwnership(vehicle)
            else
                ESX.ShowNotification("Could not get vehicle plate")
            end
        else
            ESX.ShowNotification("Vehicle does not exist")
        end
    else
        ESX.ShowNotification("No vehicle nearby")
    end
end, false)