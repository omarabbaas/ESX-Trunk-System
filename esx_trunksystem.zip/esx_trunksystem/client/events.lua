-- NUI Callbacks
RegisterNUICallback('close', function(data, cb)
    if Config.Debug then
        print("NUI callback: close received")
    end
    
    -- Make sure we really close the trunk
    CloseTrunk()
    
    -- Set a delayed check to make sure trunk door closes
    Citizen.SetTimeout(500, function()
        if CurrentVehicle and DoesEntityExist(CurrentVehicle) then
            local doorIndex = CurrentDoorIndex or Config.TrunkDoorIndex or 5
            
            if GetVehicleDoorAngleRatio(CurrentVehicle, doorIndex) > 0.1 then
                -- Force close with higher priority
                SetVehicleDoorShut(CurrentVehicle, doorIndex, true)
                
                -- If that failed, try ALL doors
                Citizen.Wait(100)
                if GetVehicleDoorAngleRatio(CurrentVehicle, doorIndex) > 0.1 then
                    for i = 0, 7 do
                        SetVehicleDoorShut(CurrentVehicle, i, true)
                    end
                end
            end
        end
    end)
    
    if cb then cb('ok') end
end)

RegisterNUICallback('addItem', function(data, cb)
    if Config.Debug then
        print("NUI callback: addItem received for " .. (data.item or "nil"))
        print("Plate: " .. (data.plate or "nil"))
        print("Count: " .. (data.count or "nil"))
    end
    
    -- Verify data before sending to server
    if not data.plate or data.plate == "" then
        if Config.Debug then
            print("Error: Missing plate in addItem callback")
        end
        return
    end
    
    if not data.item or data.item == "" then
        if Config.Debug then
            print("Error: Missing item in addItem callback")
        end
        return
    end
    
    if not data.count or data.count <= 0 then
        if Config.Debug then
            print("Error: Invalid count in addItem callback")
        end
        return
    end
    
    -- Send to server
    TriggerServerEvent('esx_trunk:addItem', data.plate, data.item, data.count)
    
    if cb then cb('ok') end
end)

RegisterNUICallback('removeItem', function(data, cb)
    if Config.Debug then
        print("NUI callback: removeItem received for " .. (data.item or "nil"))
        print("Plate: " .. (data.plate or "nil"))
        print("Count: " .. (data.count or "nil"))
    end
    
    -- Verify data before sending to server
    if not data.plate or data.plate == "" then
        if Config.Debug then
            print("Error: Missing plate in removeItem callback")
        end
        return
    end
    
    if not data.item or data.item == "" then
        if Config.Debug then
            print("Error: Missing item in removeItem callback")
        end
        return
    end
    
    if not data.count or data.count <= 0 then
        if Config.Debug then
            print("Error: Invalid count in removeItem callback")
        end
        return
    end
    
    -- Send to server
    TriggerServerEvent('esx_trunk:removeItem', data.plate, data.item, data.count)
    
    if cb then cb('ok') end
end)

-- Add callback for getting player inventory
RegisterNUICallback('getPlayerInventory', function(data, cb)
    if Config.Debug then
        print("NUI callback: getPlayerInventory received")
    end
    
    ESX.TriggerServerCallback('esx_trunk:getPlayerInventory', function(playerData)
        if cb then cb(json.encode(playerData)) end
    end)
end)

-- Event handlers for server responses
RegisterNetEvent('esx_trunk:refreshInventory')
AddEventHandler('esx_trunk:refreshInventory', function(inventory, plate)
    if TrunkOpen then
        if Config.Debug then
            print("Refreshing inventory UI for plate: " .. (plate or "unknown"))
            print("Inventory weight: " .. (inventory and inventory.weight or "nil"))
            print("Inventory items count: " .. (inventory and inventory.items and #inventory.items or "nil"))
        end
        
        -- Make sure we include the plate in refresh data
        if inventory and not inventory.plate then
            inventory.plate = plate
        end
        
        -- Update the UI with new inventory data
        SendNUIMessage({
            action = "refresh",
            inventory = inventory,
            plate = plate
        })
    end
end)

-- Emergency escape key thread (in case UI gets stuck)
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsControlJustPressed(0, 177) then -- Backspace key
            if TrunkOpen then
                if Config.Debug then
                    print("Emergency trunk close triggered")
                end
                CloseTrunk()
            end
        end
    end
end)