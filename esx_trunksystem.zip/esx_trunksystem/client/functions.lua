-- Function to open trunk UI
function OpenTrunk(vehicle)
    -- Early return to prevent errors
    if not vehicle or not DoesEntityExist(vehicle) then
        ESX.ShowNotification("Error: Vehicle does not exist")
        return 
    end
    
    -- Check if player is in a vehicle
    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) and not Config.AllowFromInsideVehicle then
        ESX.ShowNotification("You cannot access the trunk from inside a vehicle")
        return
    end
    
    -- Get vehicle info
    local vehicleProps = ESX.Game.GetVehicleProperties(vehicle)
    local plate = vehicleProps.plate or "UNKNOWN"
    local locked = GetVehicleDoorLockStatus(vehicle) > 1
    local vehicleClass = GetVehicleClass(vehicle)
    local vehicleModel = GetEntityModel(vehicle)
    local modelName = GetDisplayNameFromVehicleModel(vehicleModel):lower()
    
    if Config.Debug then
        print("Opening trunk for vehicle:", modelName, "Class:", vehicleClass, "Plate:", plate)
    end
    
    -- Debug ownership check if ALT key is pressed
    if Config.Debug and IsControlPressed(0, 19) then -- LEFT ALT key
        DebugVehicleOwnership(vehicle)
    end
    
    -- Check if vehicle is locked
    if locked and not Config.AllowLockpicking then
        -- Special check for police job
        local playerData = ESX.GetPlayerData()
        if playerData.job and Config.JobAccess[playerData.job.name] then
            -- Police can access locked trunks
            if Config.Debug then
                print("Job with access permission accessing locked trunk:", playerData.job.name)
            end
        else
            ESX.ShowNotification("Vehicle is locked")
            return
        end
    end
    
    -- If vehicle is locked and lockpicking is allowed, try lockpicking
    if locked and Config.AllowLockpicking then
        LockpickTrunk(vehicle)
        return
    end
    
    -- Access is now handled directly in the server-side getTrunkInventory function
    -- We don't need to check vehicle ownership client-side anymore
    ContinueOpeningTrunk(vehicle, plate, locked, vehicleClass, vehicleModel, modelName)
end

-- Function to debug vehicle ownership
function DebugVehicleOwnership(vehicle)
    if not Config.Debug then return end
    
    -- Early return to prevent errors
    if not vehicle or not DoesEntityExist(vehicle) then return end
    
    -- Get vehicle info
    local vehicleProps = ESX.Game.GetVehicleProperties(vehicle)
    local plate = vehicleProps.plate or "UNKNOWN"
    local vehicleModel = GetEntityModel(vehicle)
    local modelName = GetDisplayNameFromVehicleModel(vehicleModel):lower()
    
    -- Send debug info to server and chat
    print("^3[DEBUG] Trying to access vehicle:^0")
    print("^3[DEBUG] Plate: " .. plate .. "^0")
    print("^3[DEBUG] Model: " .. modelName .. "^0")
    
    -- Add this debug callback to check why ownership is failing
    ESX.TriggerServerCallback('esx_trunk:debugOwnership', function(result)
        if result then
            print("^3[DEBUG] Ownership check result: " .. tostring(result.hasAccess) .. "^0")
            print("^3[DEBUG] Reason: " .. result.reason .. "^0")
            
            -- Show notification with debug info
            ESX.ShowNotification("DEBUG: " .. result.reason)
        else
            print("^1[ERROR] Debug callback returned nil result^0")
            ESX.ShowNotification("DEBUG: Error in ownership check")
        end
    end, plate, modelName)
end

-- Continue trunk opening after permission check
function ContinueOpeningTrunk(vehicle, plate, locked, vehicleClass, vehicleModel, modelName)
    -- Early return to prevent errors
    if not vehicle or not DoesEntityExist(vehicle) then 
        ESX.ShowNotification("Error: Vehicle no longer exists")
        return 
    end
    
    -- Skip if trunk is already open
    if TrunkOpen then
        if Config.Debug then
            print("Trunk is already open, skipping")
        end
        return
    end
    
    -- Check player health
    local playerPed = PlayerPedId()
    if IsEntityDead(playerPed) then
        if Config.Debug then
            print("Player is dead, can't open trunk")
        end
        ESX.ShowNotification("You can't access the trunk while dead")
        TrunkOpen = false
        return
    end
    
    -- Set trunk open flag BEFORE UI operations
    TrunkOpen = true
    if Config.Debug then
        print("Setting TrunkOpen = true")
    end
    
    -- Store current vehicle for tracking
    CurrentVehicle = vehicle
    
    -- Determine trunk capacity based on vehicle class or special vehicle
    local capacity = Config.MaxWeight -- Default capacity
    
    -- Check if we have special capacity for this model
    if modelName and Config.SpecialVehicles and Config.SpecialVehicles[modelName] then
        capacity = Config.SpecialVehicles[modelName]
    -- Check for vehicle class capacity
    elseif vehicleClass ~= nil and Config.VehicleClasses and Config.VehicleClasses[vehicleClass] and 
           Config.VehicleClasses[vehicleClass].capacity ~= nil then
        capacity = Config.VehicleClasses[vehicleClass].capacity
    end
    
    -- Determine capacity based on job vehicle type if applicable
    if string.match(plate:upper(), "^WORK") then
        -- Parse job type from plate
        local jobCode = string.match(plate:upper(), "^WORK(%w+)")
        
        if jobCode and Config.JobVehicleTypes and Config.JobVehicleTypes[jobCode] then
            local jobType = Config.JobVehicleTypes[jobCode]
            
            -- Use job-specific capacity if defined
            if Config.JobVehicleCapacities and Config.JobVehicleCapacities[jobType] then
                capacity = Config.JobVehicleCapacities[jobType]
                
                if Config.Debug then
                    print("Using job-specific capacity for " .. jobType .. ": " .. capacity)
                end
            end
        end
    end
    
    -- Open trunk animation
    if Config.UseAnimations then
        PlayTrunkOpenAnimation()
    end
    
    -- Determine door index for trunk
    local doorIndex = Config.TrunkDoorIndex or 5
    
    -- Special door index for specific vehicle models
    if Config.SpecialDoorIndices and Config.SpecialDoorIndices[modelName] then
        doorIndex = Config.SpecialDoorIndices[modelName]
    end
    
    -- Special handling for police vehicles
    if Config.PoliceVehicles and Config.PoliceVehicles[modelName] and Config.PoliceDoorIndex then
        doorIndex = Config.PoliceDoorIndex
    end
    
    -- Print door index for debugging
    if Config.Debug then
        print("Using door index:", doorIndex, "for vehicle:", modelName)
    end
    
    -- Open trunk door with multiple attempts
    local doorOpened = false
    local attempts = 0
    local maxAttempts = 3
    
    while not doorOpened and attempts < maxAttempts do
        SetVehicleDoorOpen(vehicle, doorIndex, false, false)
        Citizen.Wait(100) -- Short wait to allow the game to process
        
        -- Check if door is now open
        if GetVehicleDoorAngleRatio(vehicle, doorIndex) > 0.1 then
            doorOpened = true
        else
            attempts = attempts + 1
        end
    end
    
    -- If still not open, try alternative door indices
    if not doorOpened then
        for i = 2, 6 do -- Try door indices 2 through 6
            if Config.Debug then
                print("Trying alternative door index:", i)
            end
            
            SetVehicleDoorOpen(vehicle, i, false, false)
            Citizen.Wait(100)
            
            if GetVehicleDoorAngleRatio(vehicle, i) > 0.1 then
                doorOpened = true
                if Config.Debug then
                    print("Found working door index:", i)
                end
                doorIndex = i
                break
            end
        end
    end
    
    -- Small delay before opening UI
    Citizen.Wait(200)
    
    -- Request trunk data from server
    ESX.TriggerServerCallback('esx_trunk:getTrunkInventory', function(inventory)
        if Config.Debug then
            print("Got trunk inventory, opening UI")
        end
        
        -- If inventory is nil, access was denied
        if inventory == nil then
            ESX.ShowNotification("You don't have access to this trunk")
            TrunkOpen = false
            
            -- Close the trunk door that was opened
            if CurrentVehicle and DoesEntityExist(CurrentVehicle) then
                SetVehicleDoorShut(CurrentVehicle, doorIndex, false)
            end
            
            CurrentVehicle = nil
            CurrentDoorIndex = nil
            return
        end
        
        -- Make sure inventory is valid
        if not inventory.items then
            inventory.items = {}
        end
        if not inventory.weight then
            inventory.weight = 0
        end
        
        -- Store door index for closing later
        CurrentDoorIndex = doorIndex
        
        -- Check if this is a job trunk
        local isJobTrunk = inventory.isJobTrunk or false
        local jobType = inventory.jobType or nil
        
        -- Send specialized data for job trunks
        if isJobTrunk and jobType then
            -- Get job-specific item limits if defined
            local itemLimits = {}
            if Config.JobItemLimits and Config.JobItemLimits[jobType] then
                itemLimits = Config.JobItemLimits[jobType]
            end
            
            SendNUIMessage({
                action = "open",
                inventory = inventory,
                capacity = capacity,
                plate = plate,
                isJobTrunk = true,
                jobType = jobType,
                jobTitle = jobType:gsub("^%l", string.upper), -- Capitalize first letter
                itemLimits = itemLimits
            })
            
            if Config.Debug then
                print("Opened job trunk UI for job type: " .. jobType)
            end
        else
            -- Standard trunk UI
            SendNUIMessage({
                action = "open",
                inventory = inventory,
                capacity = capacity,
                plate = plate
            })
        end
        
        -- Set NUI focus with a slight delay to avoid conflicts
        Citizen.Wait(100)
        SetNuiFocus(true, true)
    end, plate)
end

-- Close trunk function
function CloseTrunk()
    if not TrunkOpen then
        -- Avoid closing if not actually open
        if Config.Debug then
            print("Trunk not open, skipping close")
        end
        return
    end
    
    if Config.Debug then
        print("Closing trunk UI")
    end
    
    -- Set trunk closed flag BEFORE UI operations
    TrunkOpen = false
    
    -- Set NuiFocus false first (most important, to restore controls)
    SetNuiFocus(false, false)
    
    -- Make sure to close the physical trunk door
    if CurrentVehicle and DoesEntityExist(CurrentVehicle) then
        if Config.Debug then
            print("Closing physical trunk door")
        end
        
        -- Get the door index we used for opening
        local doorIndex = CurrentDoorIndex or Config.TrunkDoorIndex or 5
        
        -- Force close the trunk door with retries
        local attempts = 0
        local maxAttempts = Config.ExtraClosingAttempts or 3
        local doorClosed = false
        
        while not doorClosed and attempts < maxAttempts do
            SetVehicleDoorShut(CurrentVehicle, doorIndex, Config.ForceCloseDoors or false)
            Citizen.Wait(100) -- Short wait to allow the game to process
            
            -- Check if door is now closed
            if GetVehicleDoorAngleRatio(CurrentVehicle, doorIndex) < 0.1 then
                doorClosed = true
                if Config.Debug then
                    print("Door closed successfully")
                end
            else
                attempts = attempts + 1
                if Config.Debug then
                    print("Attempt", attempts, "to close door")
                end
            end
        end
        
        -- If still not closed after retries, try one more time with force
        if not doorClosed then
            if Config.Debug then
                print("Forcing door shut")
            end
            SetVehicleDoorShut(CurrentVehicle, doorIndex, true) -- Force it closed
            
            -- Try to close ALL doors as a last resort
            for i = 0, 7 do
                if GetVehicleDoorAngleRatio(CurrentVehicle, i) > 0.1 then
                    SetVehicleDoorShut(CurrentVehicle, i, true)
                end
            end
        end
    end
    
    -- Don't clear vehicle reference immediately to allow door close monitoring
    -- CurrentVehicle will be cleared by the monitoring thread once door is closed
    
    -- Close UI
    SendNUIMessage({
        action = "close"
    })
end

-- Function to lockpick trunk
function LockpickTrunk(vehicle)
    -- Early return to prevent errors
    if not vehicle or not DoesEntityExist(vehicle) then return end
    
    -- Check if player has lockpick item
    ESX.TriggerServerCallback('esx:getPlayerData', function(data)
        local hasLockpick = false
        
        if data and data.inventory then
            for i=1, #data.inventory do
                if data.inventory[i].name == Config.LockpickItem and data.inventory[i].count > 0 then
                    hasLockpick = true
                    break
                end
            end
        end
        
        if not hasLockpick then
            ESX.ShowNotification("You need a lockpick to open this trunk")
            return
        end
        
        -- Lockpicking mini-game or timer would go here
        ESX.ShowNotification("Lockpicking trunk...")
        
        -- Start lockpicking animation
        local playerPed = PlayerPedId()
        local dict = "anim@amb@clubhouse@tutorial@bkr_tut_ig3@"
        local anim = "machinic_loop_mechandplayer"
        
        RequestAnimDict(dict)
        local timeout = 1000 -- 1 second timeout for animation loading
        local startTime = GetGameTimer()
        
        -- Wait for animation to load with timeout
        while not HasAnimDictLoaded(dict) and GetGameTimer() - startTime < timeout do
            Citizen.Wait(10)
        end
        
        if HasAnimDictLoaded(dict) then
            TaskPlayAnim(playerPed, dict, anim, 8.0, -8.0, -1, 1, 0, false, false, false)
        else
            -- Fallback if animation fails to load
            if Config.Debug then
                print("Failed to load lockpick animation - using fallback")
            end
        end
        
        -- Skill check if enabled
        if Config.LockpickSkillCheck then
            -- Implement skill check mini-game
            -- This depends on what skill check resource you use (e.g., skillbar, etc.)
            -- For now, we'll use a simple timer
            Citizen.Wait(Config.LockpickTime or 10000)
        else
            -- Simple timer
            Citizen.Wait(Config.LockpickTime or 10000)
        end
        
        -- Random success chance
        if math.random(1, 100) <= 70 then -- 70% success rate
            ClearPedTasks(playerPed)
            
            -- Remove one lockpick item
            TriggerServerEvent('esx:removeInventoryItem', Config.LockpickItem, 1)
            
            ESX.ShowNotification("You successfully lockpicked the trunk")
            OpenTrunk(vehicle)
        else
            ClearPedTasks(playerPed)
            
            -- Remove one lockpick item
            TriggerServerEvent('esx:removeInventoryItem', Config.LockpickItem, 1)
            
            ESX.ShowNotification("Lockpicking failed")
        end
    end)
end

-- Play trunk opening animation
function PlayTrunkOpenAnimation()
    local playerPed = PlayerPedId()
    local dict = "anim@heists@prison_heiststation@cop_reactions"
    local anim = "cop_b_idle"
    
    -- Use config animation if available
    if Config.TrunkOpenAnimation then
        dict = Config.TrunkOpenAnimation.dict or dict
        anim = Config.TrunkOpenAnimation.name or anim
    end
    
    RequestAnimDict(dict)
    local timeout = 1000 -- 1 second timeout for animation loading
    local startTime = GetGameTimer()
    
    -- Wait for animation to load with timeout
    while not HasAnimDictLoaded(dict) and GetGameTimer() - startTime < timeout do
        Citizen.Wait(10)
    end
    
    if HasAnimDictLoaded(dict) then
        TaskPlayAnim(playerPed, dict, anim, 8.0, 8.0, -1, 50, 0, false, false, false)
        Citizen.Wait(1000)
        ClearPedTasks(playerPed)
    else
        -- Fallback if animation fails to load
        if Config.Debug then
            print("Failed to load trunk animation - skipping")
        end
    end
end

-- Function to check if a vehicle has a trunk
function HasTrunk(vehicle)
    if not vehicle or not DoesEntityExist(vehicle) then return false end
    
    local vehicleClass = GetVehicleClass(vehicle)
    
    -- Vehicle classes that don't have trunks
    local noTrunkClasses = {
        [8] = true,  -- Motorcycles
        [13] = true, -- Bicycles
        [14] = true, -- Boats
        [15] = true, -- Helicopters
        [16] = true  -- Planes
    }
    
    -- Check if vehicle class has no trunk
    if noTrunkClasses[vehicleClass] then
        return false
    end
    
    return true
end

-- Get trunk position for a vehicle
function GetTrunkPosition(vehicle)
    if not vehicle or not DoesEntityExist(vehicle) then return nil end
    
    local vehicleModel = GetEntityModel(vehicle)
    local modelName = GetDisplayNameFromVehicleModel(vehicleModel):lower()
    
    -- Get the dimensions of the vehicle
    local min, max = GetModelDimensions(vehicleModel)
    
    -- Default trunk position at the back of the vehicle
    local trunkOffset = vector3(0.0, min.y - 0.5, 0.0)
    
    -- Special trunk positions for specific vehicle models (if available in config)
    local specialPositions = {
        ["panto"] = vector3(0.0, min.y - 0.2, 0.0),      -- Smaller offset for tiny cars
        ["issi2"] = vector3(0.0, min.y - 0.2, 0.0),      -- Smaller offset for tiny cars
        ["journey"] = vector3(0.0, min.y - 1.0, 0.0),    -- Larger offset for RVs
        ["youga"] = vector3(0.0, min.y - 1.0, 0.0),      -- Larger offset for vans
        ["boxville"] = vector3(0.0, min.y - 1.5, 0.0),   -- Larger offset for box trucks
    }
    
    -- Use special position if defined for this model
    if specialPositions[modelName] then
        trunkOffset = specialPositions[modelName]
    end
    
    -- Calculate world position of trunk
    return GetOffsetFromEntityInWorldCoords(vehicle, trunkOffset.x, trunkOffset.y, trunkOffset.z)
end