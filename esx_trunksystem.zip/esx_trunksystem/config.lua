Config = {}

-- General Settings
Config.Debug = true                 -- Enable debug mode for development (set to false in production)
Config.UseWeight = true             -- Use weight system instead of slots
Config.MaxWeight = 100              -- Default max weight for standard vehicles
Config.OpenKey = 'E'                -- Key to open trunk when near vehicle's trunk
Config.TrunkDistance = 2.0          -- Distance to trunk to allow interaction
Config.AllowFromInsideVehicle = false  -- Whether players can access trunk from inside vehicle

-- Auto-close Settings
Config.AutoCloseEnabled = true      -- Whether to automatically close trunk when player walks away
Config.AutoCloseUI = true           -- Whether to close UI when trunk closes
Config.AutoCloseNotify = true       -- Show notification when trunk auto-closes

-- Ownership Settings
Config.AutoClaimUnownedTrunks = false  -- Automatically claim unowned trunks when accessing them
Config.ShowAccessDenied = true        -- Show notification when access is denied
Config.AllowNonOwnedVehicles = true   -- Allow access to vehicles not in owned_vehicles table
Config.AutoCreateTrunksForUnownedVehicles = false  -- Set to false to prevent creating trunks for unowned vehicles



-- Door handling settings
Config.ForceCloseDoors = true       -- Force close doors that get stuck
Config.TrunkDoorIndex = 5           -- Door index for trunk (5 is standard, some vehicles might use different values)
Config.ExtraClosingAttempts = 3     -- Number of attempts to close a stuck door

-- Vehicle Classes and Capacities
Config.VehicleClasses = {
    [0] = { name = "Compact", capacity = 30 },        -- Compact
    [1] = { name = "Sedan", capacity = 50 },          -- Sedan
    [2] = { name = "SUV", capacity = 80 },            -- SUV
    [3] = { name = "Coupe", capacity = 40 },          -- Coupe
    [4] = { name = "Muscle", capacity = 50 },         -- Muscle
    [5] = { name = "Sports Classic", capacity = 30 }, -- Sports Classic
    [6] = { name = "Sports", capacity = 30 },         -- Sports
    [7] = { name = "Super", capacity = 20 },          -- Super
    [8] = { name = "Motorcycle", capacity = 15 },     -- Motorcycle
    [9] = { name = "Off-road", capacity = 70 },       -- Off-road
    [10] = { name = "Industrial", capacity = 150 },   -- Industrial
    [11] = { name = "Utility", capacity = 120 },      -- Utility
    [12] = { name = "Van", capacity = 100 },          -- Van
    [13] = { name = "Bicycle", capacity = 5 },        -- Bicycle
    [14] = { name = "Boat", capacity = 40 },          -- Boat
    [15] = { name = "Helicopter", capacity = 60 },    -- Helicopter
    [16] = { name = "Plane", capacity = 120 },        -- Plane
    [17] = { name = "Service", capacity = 80 },       -- Service
    [18] = { name = "Emergency", capacity = 100 },    -- Emergency
    [19] = { name = "Military", capacity = 120 },     -- Military
    [20] = { name = "Commercial", capacity = 200 }    -- Commercial
}

-- Special Vehicles with Custom Capacities
Config.SpecialVehicles = {
    ["stockade"] = 300,   -- Money truck
    ["benson"] = 250,     -- Delivery truck
    ["rumpo"] = 150,      -- Van
}

-- Security Settings
Config.RequireVehicleOwnership = true  -- Only vehicle owner can access trunk
Config.AllowLockpicking = true         -- Allow lockpicking trunks of locked vehicles
Config.LockpickItem = 'lockpick'       -- Item required for lockpicking
Config.LockpickTime = 10000            -- Time in ms to lockpick
Config.LockpickSkillCheck = false      -- Use skill check for lockpicking

-- Job Access Permissions
Config.JobAccess = {
    ['police'] = true,    -- Police can search all trunks
    ['sheriff'] = true,   -- Sheriff can search all trunks
}

-- Direct police vehicle handling (immediate bypass for all restrictions)
Config.PoliceVehicles = {
    ["police"] = true,
    ["police2"] = true,
    ["police3"] = true,
    ["police4"] = true,
    ["policeb"] = true,
    ["policet"] = true,
    ["sheriff"] = true,
    ["sheriff2"] = true,
    ["fbi"] = true,
    ["fbi2"] = true,
}

-- Special door indices for specific vehicles
Config.SpecialDoorIndices = {
    ["police"] = 5,
    ["police2"] = 5,
    ["police3"] = 5,
    ["police4"] = 5,
}

-- Default door index for police vehicles
Config.PoliceDoorIndex = 5

-- Blacklisted Items (cannot be stored in trunks)
Config.BlacklistedItems = {
    'black_money',
    -- Add more items as needed
}

-- Animation Settings
Config.UseAnimations = true
Config.TrunkOpenAnimation = {
    dict = "anim@heists@prison_heiststation@cop_reactions",
    name = "cop_b_idle"
}

-- Job Vehicle Settings
Config.AllowAnyJobVehicleAccess = false  -- If true, any player can access any job vehicle trunk

-- Job Vehicle Type Mapping (from plate codes to job names)
Config.JobVehicleTypes = {
    ["MIN"] = "miner",
    ["LUM"] = "lumberjack", 
    ["TAI"] = "tailor",
    ["FIS"] = "fisherman",
    ["FAR"] = "farmer",
    ["OIL"] = "fueler",
}

-- Job Vehicle Capacities (optional)
Config.JobVehicleCapacities = {
    ["miner"] = 200,      -- Mining vehicles have larger capacity
    ["lumberjack"] = 250, -- Lumberjack vehicles have even larger capacity
    ["tailor"] = 100,     -- Tailor vehicles have medium capacity
    ["fisherman"] = 150,  -- Fishing vehicles
    ["farmer"] = 300,     -- Farming vehicles
    ["fueler"] = 100,     -- Oil/fuel trucks
}