fx_version 'cerulean'
game 'gta5'

author 'Omar Abbaas'
description 'ESX Trunk System - Vehicle Storage'
version '1.0.0'

shared_scripts {
    '@es_extended/imports.lua',
    'config.lua'
}

-- IMPORTANT: Properly order client scripts!
client_scripts {
    'client/functions.lua',  -- Functions MUST be loaded first
    'client/client.lua',     -- Then the main client script
    'client/events.lua',     -- Then events
    'client/commands.lua'    -- Then commands
}

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    'server/server.lua',
    'server/functions.lua',
    'server/events.lua',
    'server/commands.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/css/style.css',
    'html/js/script.js',
    'html/img/default.png'
}

dependencies {
    'es_extended'
}