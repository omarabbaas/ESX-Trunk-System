// Global variables with default values to prevent undefined
let inventoryData = {
    items: [],
    weight: 0,
    maxWeight: 100,
    plate: "",
    isJobTrunk: false,
    jobType: null
};

let playerInventory = [];
let selectedItem = null;
let selectedInventory = null;
let maxQuantity = 0;

// Initialize when DOM is ready
$(document).ready(function() {
    console.log("ESX Trunk UI loaded and ready");
    
    // Close button listener
    $("#close-button").on("click", function() {
        console.log("Close button clicked");
        closeInventory();
    });

    // Escape key to close inventory
    $(document).on("keyup", function(e) {
        if (e.key === "Escape") {
            console.log("Escape key pressed");
            closeInventory();
        }
    });

    // Search functionality
    $("#player-search").on("input", function() {
        const searchValue = $(this).val().toLowerCase();
        filterItems("#player-items", searchValue);
    });

    $("#trunk-search").on("input", function() {
        const searchValue = $(this).val().toLowerCase();
        filterItems("#trunk-items", searchValue);
    });
    
    // Quantity dialog buttons
    $(".quantity-button").on("click", function() {
        const amount = parseInt($(this).data("amount"));
        let currentValue = parseInt($("#quantity-value").val()) || 0;
        
        if (amount === 100) {
            // Max button - set to maxQuantity
            $("#quantity-value").val(maxQuantity);
        } else {
            // Add the amount
            currentValue += amount;
            // Make sure we don't exceed max
            if (currentValue > maxQuantity) {
                currentValue = maxQuantity;
            }
            $("#quantity-value").val(currentValue);
        }
    });
    
    // Cancel button
    $(".cancel-btn").on("click", function() {
        $("#quantity-dialog").hide();
    });
    
    // Confirm button
    $(".confirm-btn").on("click", function() {
        const count = parseInt($("#quantity-value").val());
        
        if (count > 0 && count <= maxQuantity) {
            // DEBUG: Log the plate before sending
            console.log("Current plate before sending:", inventoryData.plate);
            
            if (!inventoryData.plate || inventoryData.plate === "") {
                console.error("ERROR: Plate is empty or undefined!");
                showNotification("Error: Vehicle plate is missing. Please try reopening the trunk.");
                return;
            }
            
            if (selectedInventory === "player") {
                // Transfer from player to trunk
                console.log("Adding item to trunk with plate:", inventoryData.plate);
                $.post('https://esx_trunksystem/addItem', JSON.stringify({
                    plate: inventoryData.plate,
                    item: selectedItem.name,
                    count: count
                }));
            } else {
                // Transfer from trunk to player
                console.log("Removing item from trunk with plate:", inventoryData.plate);
                $.post('https://esx_trunksystem/removeItem', JSON.stringify({
                    plate: inventoryData.plate,
                    item: selectedItem.name,
                    count: count
                }));
            }
            
            $("#quantity-dialog").hide();
        }
    });
});

// Function to show a notification
function showNotification(message) {
    if (!$(".notification-container").length) {
        $("body").append('<div class="notification-container"></div>');
    }
    
    const notification = $(`<div class="notification">${message}</div>`);
    $(".notification-container").append(notification);
    
    setTimeout(() => {
        notification.addClass("show");
        
        setTimeout(() => {
            notification.removeClass("show");
            setTimeout(() => {
                notification.remove();
            }, 500);
        }, 3000);
    }, 100);
}

// Function to filter items based on search
function filterItems(containerId, searchValue) {
    $(`${containerId} .item`).each(function() {
        const itemName = $(this).data("name").toLowerCase();
        const itemLabel = $(this).find(".item-name").text().toLowerCase();
        
        if (itemName.includes(searchValue) || itemLabel.includes(searchValue)) {
            $(this).show();
        } else {
            $(this).hide();
        }
    });
}

// Show quantity dialog for item transfer
function showQuantityDialog(item, source) {
    selectedItem = item;
    selectedInventory = source;
    maxQuantity = item.count;
    
    // Set max value and reset to 1
    $("#quantity-value").attr("max", maxQuantity);
    $("#quantity-value").val(1);
    
    // Position in center
    $("#quantity-dialog").show();
}

// Display player inventory
function displayPlayerInventory(items) {
    const container = $("#player-items");
    container.empty();
    
    playerInventory = items || [];
    
    if (!items || items.length === 0) {
        container.html("<div class='no-items'>Your inventory is empty</div>");
        return;
    }
    
    items.forEach(item => {
        const itemElement = $(`
            <div class="item" data-name="${item.name}" data-count="${item.count}">
                <img src="img/${item.name}.png" onerror="this.src='img/default.png'">
                <div class="item-name">${item.label || item.name}</div>
                <div class="item-count">x${item.count}</div>
            </div>
        `);
        
        // Double click to transfer
        itemElement.on("dblclick", function() {
            showQuantityDialog(item, "player");
        });
        
        container.append(itemElement);
    });
}

// Display trunk inventory
function displayTrunkInventory(inventory) {
    const container = $("#trunk-items");
    container.empty();
    
    // Make sure inventory is valid
    if (!inventory) {
        console.error("Error: Received null inventory");
        container.html("<div class='no-items'>Error loading trunk inventory</div>");
        return;
    }
    
    // Handle missing data in inventory
    const safeInventory = {
        items: inventory.items || [],
        weight: inventory.weight || 0,
        capacity: inventory.capacity || inventoryData.capacity || 100,
        plate: inventory.plate || inventoryData.plate || "UNKNOWN",
        isJobTrunk: inventory.isJobTrunk || false,
        jobType: inventory.jobType || null
    };
    
    // Store inventory data globally, ensure plate is stored correctly
    inventoryData = safeInventory;
    
    // Debug plate to make sure it's being stored
    console.log("Stored plate:", inventoryData.plate);
    
    // Add plate display in UI for debugging (you can remove this in production)
    $("#plate-debug").remove();
    $(".header").append(`<div id="plate-debug" style="position: absolute; right: 70px; color: rgba(255,255,255,0.5); font-size: 12px;">Plate: ${inventoryData.plate}</div>`);
    
    // Update weight display
    const weightPercentage = (safeInventory.weight / safeInventory.capacity) * 100;
    $("#weight-fill").css("width", `${Math.min(weightPercentage, 100)}%`);
    
    // Update weight text with safe values
    $("#weight-text").text(`${safeInventory.weight.toFixed(1)}/${safeInventory.capacity}`);
    
    // Change color based on weight
    if (weightPercentage < 50) {
        $("#weight-fill").css("background-color", "#4caf50");
    } else if (weightPercentage < 85) {
        $("#weight-fill").css("background-color", "#ff9800");
    } else {
        $("#weight-fill").css("background-color", "#f44336");
    }
    
    // Check if this is a job trunk
    if (safeInventory.isJobTrunk && safeInventory.jobType) {
        // Show job tag
        $("#job-tag").removeClass("hidden");
        $("#job-name").text(safeInventory.jobTitle || safeInventory.jobType.toUpperCase());
        
        // Add job-specific styling if needed
        $("#job-tag").css("background-color", getJobColor(safeInventory.jobType));
    } else {
        // Hide job tag for regular trunks
        $("#job-tag").addClass("hidden");
    }
    
    // Check if inventory is empty
    if (!safeInventory.items || safeInventory.items.length === 0) {
        container.html("<div class='no-items'>This trunk is empty</div>");
        return;
    }
    
    safeInventory.items.forEach(item => {
        if (!item) return; // Skip invalid items
        
        const itemElement = $(`
            <div class="item" data-name="${item.name}" data-count="${item.count}">
                <img src="img/${item.name}.png" onerror="this.src='img/default.png'">
                <div class="item-name">${item.label || item.name}</div>
                <div class="item-count">x${item.count}</div>
            </div>
        `);
        
        // Double click to transfer
        itemElement.on("dblclick", function() {
            showQuantityDialog(item, "trunk");
        });
        
        container.append(itemElement);
    });
}

// Get color for job type
function getJobColor(jobType) {
    const colorMap = {
        "miner": "#607d8b",      // Blue grey
        "lumberjack": "#795548", // Brown
        "tailor": "#9c27b0",     // Purple
        "fisherman": "#03a9f4",  // Light blue
        "farmer": "#8bc34a",     // Light green
        "fueler": "#ff5722",     // Deep orange
        "mechanic": "#ff9800",   // Orange
        "police": "#3f51b5",     // Indigo
        "ambulance": "#f44336"   // Red
    };
    
    return colorMap[jobType] || "#2c5aa0"; // Default blue
}

// Close inventory and send NUI message back
function closeInventory() {
    console.log("Closing inventory");
    $("#trunk-container").removeClass("visible");
    
    // Delay hiding to allow animation
    setTimeout(() => {
        $("#trunk-container").hide();
        $.post('https://esx_trunksystem/close', JSON.stringify({}));
    }, 300);
}

// Add notification styles
$("<style>").text(`
.notification-container {
    position: fixed;
    top: 20%;
    left: 50%;
    transform: translateX(-50%);
    z-index: 1000;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
}
.notification {
    background-color: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 10px 20px;
    border-radius: 5px;
    transform: translateY(-100px);
    transition: transform 0.5s ease;
    max-width: 80%;
    text-align: center;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
}
.notification.show {
    transform: translateY(0);
}
`).appendTo("head");

// NUI message handler
window.addEventListener('message', function(event) {
    const data = event.data;
    
    if (data.action === "open") {
        console.log("Opening trunk UI");
        
        // Debug the plate received from server
        console.log("Received plate from server:", data.plate);
        
        // Store capacity and plate
        inventoryData.capacity = data.capacity || 100;
        inventoryData.plate = data.plate || "UNKNOWN";
        inventoryData.isJobTrunk = data.isJobTrunk || false;
        inventoryData.jobType = data.jobType || null;
        
        // Request player inventory
        $.post('https://esx_trunksystem/getPlayerInventory', JSON.stringify({}), function(response) {
            try {
                playerInventory = JSON.parse(response);
                displayPlayerInventory(playerInventory);
                
                // Create a safety copy of inventory data
                const safeInventoryData = {
                    items: data.inventory && data.inventory.items ? data.inventory.items : [],
                    weight: data.inventory && data.inventory.weight ? data.inventory.weight : 0,
                    capacity: data.capacity || 100,
                    plate: data.plate, // Make sure plate is included
                    isJobTrunk: data.isJobTrunk || false,
                    jobType: data.jobType || null
                };
                
                displayTrunkInventory(safeInventoryData);
                
                // Show trunk UI with animation
                $("#trunk-container").show().addClass("visible");
            } catch (e) {
                console.error("Error parsing inventory:", e);
                showNotification("Error loading inventory. Please try again.");
            }
        }).fail(function() {
            console.error("Failed to get player inventory");
            showNotification("Failed to retrieve inventory data.");
        });
    } 
    else if (data.action === "refresh") {
        // Just update the trunk inventory display, but make sure the plate is preserved
        console.log("Refreshing trunk UI, preserving plate:", inventoryData.plate);
        
        // Create a safe copy of the inventory with all necessary properties
        const refreshData = {
            items: data.inventory && data.inventory.items ? data.inventory.items : [],
            weight: data.inventory && data.inventory.weight ? data.inventory.weight : 0,
            capacity: data.inventory && data.inventory.capacity ? data.inventory.capacity : inventoryData.capacity,
            // Use the existing plate if not provided in refresh data
            plate: (data.inventory && data.inventory.plate) ? data.inventory.plate : 
                  (data.plate ? data.plate : inventoryData.plate),
            isJobTrunk: (data.inventory && data.inventory.isJobTrunk) ? data.inventory.isJobTrunk : inventoryData.isJobTrunk,
            jobType: (data.inventory && data.inventory.jobType) ? data.inventory.jobType : inventoryData.jobType
        };
        
        // Debug
        console.log("Refresh data:", refreshData);
        
        // Update display with safe data
        displayTrunkInventory(refreshData);
    }
    else if (data.action === "close") {
        closeInventory();
    }
    else if (data.action === "forceRefresh") {
        // Reset everything
        $("#trunk-container").hide().removeClass("visible");
        $("#quantity-dialog").hide();
        
        // Clear inventory displays
        $("#player-items").empty();
        $("#trunk-items").empty();
        
        // Reset search fields
        $("#player-search").val("");
        $("#trunk-search").val("");
    }
});