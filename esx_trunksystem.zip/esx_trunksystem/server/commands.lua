-- Admin command to clear a vehicle trunk
ESX.RegisterCommand('cleartrunk', 'admin', function(xPlayer, args, showError)
    local plate = args.plate
    
    if not plate then
        if xPlayer then xPlayer.showNotification("Please specify a vehicle plate") end
        return
    end
    
    -- Clean plate for consistency
    local cleanPlate = string.gsub(plate, "%s", ""):upper()
    
    if Trunks[cleanPlate] then
        Trunks[cleanPlate] = {
            items = {},
            weight = 0,
            owner = Trunks[cleanPlate].owner,
            shared = Trunks[cleanPlate].shared
        }
        
        SaveTrunkInventory(cleanPlate, Trunks[cleanPlate])
        if xPlayer then xPlayer.showNotification("Trunk for plate " .. plate .. " has been cleared") end
        
        if Config.Debug then
            print("^2[ESX_TRUNK] Cleared trunk for plate " .. plate .. "^0")
        end
    else
        -- Check database
        MySQL.Async.fetchAll('SELECT * FROM trunk_inventory WHERE REPLACE(UPPER(plate), " ", "") = @plate LIMIT 1', {
            ['@plate'] = cleanPlate
        }, function(results)
            if results and #results > 0 then
                -- Update existing record
                MySQL.Async.execute('UPDATE trunk_inventory SET data = @data WHERE REPLACE(UPPER(plate), " ", "") = @plate', {
                    ['@plate'] = cleanPlate,
                    ['@data'] = json.encode({items = {}, weight = 0})
                })
                
                -- Initialize in memory
                Trunks[cleanPlate] = {
                    items = {},
                    weight = 0,
                    owner = results[1].owner,
                    shared = results[1].shared
                }
                
                if xPlayer then xPlayer.showNotification("Trunk for plate " .. plate .. " has been cleared") end
                
                if Config.Debug then
                    print("^2[ESX_TRUNK] Cleared trunk for plate " .. plate .. " from database^0")
                end
            else
                if xPlayer then xPlayer.showNotification("No trunk found for plate " .. plate) end
                
                if Config.Debug then
                    print("^3[ESX_TRUNK] No trunk found for plate " .. plate .. "^0")
                end
            end
        end)
    end
end, true, {help = "Clear a vehicle trunk", validate = true, arguments = {
    {name = 'plate', help = "Vehicle plate", type = 'string'}
}})

-- Admin command to view trunk contents
ESX.RegisterCommand('checktrunk', 'admin', function(xPlayer, args, showError)
    local plate = args.plate
    
    if not plate then
        if xPlayer then xPlayer.showNotification("Please specify a vehicle plate") end
        return
    end
    
    -- Clean plate for consistency
    local cleanPlate = string.gsub(plate, "%s", ""):upper()
    
    if Trunks[cleanPlate] then
        local itemCount = #Trunks[cleanPlate].items
        local weight = Trunks[cleanPlate].weight
        local owner = Trunks[cleanPlate].owner or "None"
        local shared = Trunks[cleanPlate].shared == 1 and "Yes" or "No"
        
        if xPlayer then 
            xPlayer.showNotification("Trunk " .. plate .. " has " .. itemCount .. " items, weight: " .. weight) 
        end
        
        -- Show items in console
        print("^3[ESX_TRUNK] Trunk contents for plate " .. plate .. ":^0")
        print("^3[ESX_TRUNK] Owner: " .. owner .. ", Shared: " .. shared .. "^0")
        
        for i=1, itemCount do
            local item = Trunks[cleanPlate].items[i]
            print("^3[ESX_TRUNK] - " .. item.label .. " x" .. item.count .. "^0")
        end
    else
        -- Check database
        MySQL.Async.fetchAll('SELECT * FROM trunk_inventory WHERE REPLACE(UPPER(plate), " ", "") = @plate LIMIT 1', {
            ['@plate'] = cleanPlate
        }, function(results)
            if results and #results > 0 then
                local trunkData = json.decode(results[1].data) or {items = {}, weight = 0}
                local itemCount = #(trunkData.items or {})
                local weight = trunkData.weight or 0
                local owner = results[1].owner or "None"
                local shared = results[1].shared == 1 and "Yes" or "No"
                
                if xPlayer then 
                    xPlayer.showNotification("Trunk " .. plate .. " has " .. itemCount .. " items, weight: " .. weight) 
                end
                
                -- Show items in console
                print("^3[ESX_TRUNK] Trunk contents for plate " .. plate .. " (from database):^0")
                print("^3[ESX_TRUNK] Owner: " .. owner .. ", Shared: " .. shared .. "^0")
                
                for i=1, itemCount do
                    local item = trunkData.items[i]
                    print("^3[ESX_TRUNK] - " .. (item.label or item.name) .. " x" .. item.count .. "^0")
                end
                
                -- Initialize in memory
                Trunks[cleanPlate] = {
                    items = trunkData.items or {},
                    weight = trunkData.weight or 0,
                    owner = results[1].owner,
                    shared = results[1].shared
                }
            else
                if xPlayer then xPlayer.showNotification("No trunk found for plate " .. plate) end
                
                if Config.Debug then
                    print("^3[ESX_TRUNK] No trunk found for plate " .. plate .. "^0")
                end
            end
        end)
    end
end, true, {help = "View trunk contents", validate = true, arguments = {
    {name = 'plate', help = "Vehicle plate", type = 'string'}
}})

-- Admin command to share a trunk
ESX.RegisterCommand('sharetrunk', 'admin', function(xPlayer, args, showError)
    local plate = args.plate
    local enable = args.enable
    
    if not plate then
        if xPlayer then xPlayer.showNotification("Please specify a vehicle plate") end
        return
    end
    
    -- Clean plate for consistency
    local cleanPlate = string.gsub(plate, "%s", ""):upper()
    local shareStatus = enable and 1 or 0
    
    -- Update database
    MySQL.Async.execute('UPDATE trunk_inventory SET shared = @shared WHERE REPLACE(UPPER(plate), " ", "") = @plate', {
        ['@plate'] = cleanPlate,
        ['@shared'] = shareStatus
    }, function(rowsChanged)
        if rowsChanged > 0 then
            -- Update in memory if exists
            if Trunks[cleanPlate] then
                Trunks[cleanPlate].shared = shareStatus
            end
            
            if xPlayer then
                if enable then
                    xPlayer.showNotification("Trunk for plate " .. plate .. " is now shared")
                else
                    xPlayer.showNotification("Trunk for plate " .. plate .. " is now private")
                end
            end
            
            if Config.Debug then
                print("^2[ESX_TRUNK] Updated sharing for plate " .. plate .. " to " .. tostring(shareStatus) .. "^0")
            end
        else
            if xPlayer then xPlayer.showNotification("No trunk found for plate " .. plate) end
            
            if Config.Debug then
                print("^3[ESX_TRUNK] No trunk found for plate " .. plate .. "^0")
            end
        end
    end)
    
end, true, {help = "Share or unshare a trunk", validate = true, arguments = {
    {name = 'plate', help = "Vehicle plate", type = 'string'},
    {name = 'enable', help = "1 to share, 0 to unshare", type = 'number'}
}})

-- Admin command to transfer trunk ownership
ESX.RegisterCommand('transfertrunk', 'admin', function(xPlayer, args, showError)
    local plate = args.plate
    local targetId = args.target
    
    if not plate or not targetId then
        if xPlayer then xPlayer.showNotification("Please specify both a plate and target player ID") end
        return
    end
    
    local targetPlayer = ESX.GetPlayerFromId(targetId)
    if not targetPlayer then
        if xPlayer then xPlayer.showNotification("Target player not found") end
        return
    end
    
    -- Clean plate for consistency
    local cleanPlate = string.gsub(plate, "%s", ""):upper()
    local targetIdentifier = targetPlayer.getIdentifier()
    
    -- Update database
    MySQL.Async.execute('UPDATE trunk_inventory SET owner = @owner WHERE REPLACE(UPPER(plate), " ", "") = @plate', {
        ['@plate'] = cleanPlate,
        ['@owner'] = targetIdentifier
    }, function(rowsChanged)
        if rowsChanged > 0 then
            -- Update in memory if exists
            if Trunks[cleanPlate] then
                Trunks[cleanPlate].owner = targetIdentifier
            end
            
            if xPlayer then
                xPlayer.showNotification("Trunk ownership for plate " .. plate .. " transferred to " .. GetPlayerName(targetId))
            end
            
            TriggerClientEvent('esx:showNotification', targetId, "You are now the owner of trunk with plate " .. plate)
            
            if Config.Debug then
                print("^2[ESX_TRUNK] Transferred ownership of plate " .. plate .. " to " .. targetIdentifier .. "^0")
            end
        else
            if xPlayer then xPlayer.showNotification("No trunk found for plate " .. plate) end
            
            if Config.Debug then
                print("^3[ESX_TRUNK] No trunk found for plate " .. plate .. "^0")
            end
        end
    end)
    
end, true, {help = "Transfer trunk ownership", validate = true, arguments = {
    {name = 'plate', help = "Vehicle plate", type = 'string'},
    {name = 'target', help = "Target player ID", type = 'number'}
}})

-- Command to fix trunk database (admin only)
ESX.RegisterCommand('fixtrunkdb', 'admin', function(xPlayer, args, showError)
    print("^3[ESX_TRUNK] Starting trunk database maintenance...^0")
    
    -- Step 1: Recalculate weights for all trunks
    local fixed = 0
    
    MySQL.Async.fetchAll('SELECT * FROM trunk_inventory', {}, function(results)
        if not results or #results == 0 then
            print("^3[ESX_TRUNK] No trunks found in database^0")
            if xPlayer then xPlayer.showNotification("No trunks found in database") end
            return
        end
        
        for _, trunk in ipairs(results) do
            local data = json.decode(trunk.data)
            
            if data then
                local needsUpdate = false
                
                -- Check for invalid weights
                if data.weight == nil or data.weight < 0 or data.weight > 1000 then
                    -- Recalculate weight
                    local newWeight = CalculateTrunkWeight(data.items or {})
                    data.weight = newWeight
                    needsUpdate = true
                    
                    if Config.Debug then
                        print("^3[ESX_TRUNK] Fixed invalid weight for plate " .. trunk.plate .. "^0")
                    end
                end
                
                -- Check for missing items array
                if data.items == nil then
                    data.items = {}
                    needsUpdate = true
                    
                    if Config.Debug then
                        print("^3[ESX_TRUNK] Fixed missing items array for plate " .. trunk.plate .. "^0")
                    end
                end
                
                -- Check for invalid items
                if data.items then
                    local itemsRemoved = false
                    for i = #data.items, 1, -1 do
                        if data.items[i] == nil or data.items[i].count == nil or data.items[i].count <= 0 then
                            table.remove(data.items, i)
                            itemsRemoved = true
                        end
                    end
                    
                    if itemsRemoved then
                        needsUpdate = true
                        
                        if Config.Debug then
                            print("^3[ESX_TRUNK] Removed invalid items from plate " .. trunk.plate .. "^0")
                        end
                    end
                end
                
                -- Update database if needed
                if needsUpdate then
                    MySQL.Async.execute('UPDATE trunk_inventory SET data = @data WHERE id = @id', {
                        ['@data'] = json.encode(data),
                        ['@id'] = trunk.id
                    })
                    
                    fixed = fixed + 1
                    
                    -- Update in-memory cache if loaded
                    if Trunks[string.gsub(trunk.plate, "%s", ""):upper()] then
                        Trunks[string.gsub(trunk.plate, "%s", ""):upper()] = {
                            items = data.items,
                            weight = data.weight,
                            owner = trunk.owner,
                            shared = trunk.shared
                        }
                    end
                end
            else
                -- Invalid JSON, reset data
                MySQL.Async.execute('UPDATE trunk_inventory SET data = @data WHERE id = @id', {
                    ['@data'] = json.encode({items = {}, weight = 0}),
                    ['@id'] = trunk.id
                })
                
                fixed = fixed + 1
                
                if Config.Debug then
                    print("^3[ESX_TRUNK] Reset invalid JSON data for plate " .. trunk.plate .. "^0")
                end
            end
        end
        
        print("^2[ESX_TRUNK] Fixed " .. fixed .. " trunks in database^0")
        if xPlayer then xPlayer.showNotification("Fixed " .. fixed .. " trunks") end
    end)
end, true, {help = "Fix trunk database issues"})