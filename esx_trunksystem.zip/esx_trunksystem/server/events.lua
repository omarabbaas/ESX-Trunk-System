-- Ensure Trunks table is initialized to prevent nil errors
if Trunks == nil then
    print("^3[ESX_TRUNK] Warning: Trunks table was nil, initializing empty table^0")
    Trunks = {}
end

-- Safe plate cleaning function
function CleanPlate(plate)
    -- Add nil check before using gsub
    if plate == nil then
        if Config.Debug then
            print("^1[ERROR] Attempted to clean a nil plate^0")
        end
        return "UNKNOWN"
    end
    return string.gsub(plate, "%s", ""):upper()
end

-- Get trunk inventory - ESX server callback
ESX.RegisterServerCallback('esx_trunk:getTrunkInventory', function(source, cb, plate)
    -- Ensure Trunks is initialized
    if Trunks == nil then
        Trunks = {}
        print("^3[ESX_TRUNK] Warning: Trunks table was nil during getTrunkInventory, initialized empty table^0")
    end
    
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.getIdentifier()
    local job = xPlayer.getJob().name
    
    -- Debug output
    if Config.Debug then
        print("^3[ESX_TRUNK] Accessing trunk with plate: " .. tostring(plate) .. "^0")
        print("^3[ESX_TRUNK] Player: " .. GetPlayerName(source) .. " ID: " .. source .. "^0")
        print("^3[ESX_TRUNK] Identifier: " .. identifier .. "^0")
        print("^3[ESX_TRUNK] Job: " .. job .. "^0")
    end
    
    -- Handle nil plate
    if not plate then
        if Config.Debug then
            print("^1[ERROR] Attempted to access trunk with nil plate^0")
        end
        cb(nil)
        return
    end
    
    -- Clean the plate for consistency
    local cleanPlate = CleanPlate(plate)
    
    -- Special handling for work vehicles with "WORK" plates
    if string.match(cleanPlate, "^WORK") then
        if Config.Debug then
            print("^3[ESX_TRUNK] Job vehicle detected: " .. cleanPlate .. "^0")
        end
        
        -- Check if player has the right job for this vehicle
        local vehicleJobType = GetJobVehicleType(cleanPlate)
        if vehicleJobType then
            -- Check if player's job matches the vehicle job type
            if job == vehicleJobType then
                if Config.Debug then
                    print("^2[ESX_TRUNK] Player job matches job vehicle type^0")
                end
                
                -- Get or create a shared job trunk
                GetOrCreateJobTrunk(cleanPlate, vehicleJobType, cb)
                return
            else
                -- Player has wrong job for this work vehicle
                if Config.Debug then
                    print("^1[ESX_TRUNK] Player has wrong job for this work vehicle^0")
                    print("^1[ESX_TRUNK] Vehicle job: " .. vehicleJobType .. ", Player job: " .. job .. "^0")
                end
                
                if Config.AllowAnyJobVehicleAccess then
                    -- Optional: Allow access anyway
                    if Config.Debug then
                        print("^3[ESX_TRUNK] AllowAnyJobVehicleAccess is enabled, granting access^0")
                    end
                    GetOrCreateJobTrunk(cleanPlate, vehicleJobType, cb)
                    return
                else
                    -- Deny access
                    if Config.ShowAccessDenied then
                        TriggerClientEvent('esx:showNotification', source, "You need to be a " .. vehicleJobType .. " to access this trunk")
                    end
                    cb(nil)
                    return
                end
            end
        else
            -- Unknown job vehicle type, default to shared access
            if Config.Debug then
                print("^3[ESX_TRUNK] Unknown job vehicle type, using shared trunk^0")
            end
            GetOrCreateJobTrunk(cleanPlate, "shared", cb)
            return
        end
    end
    
    -- Regular vehicle handling (non-job vehicles) continues below...
    -- Check if trunk exists and if player has access
    MySQL.Async.fetchAll('SELECT * FROM trunk_inventory WHERE REPLACE(UPPER(plate), " ", "") = @plate LIMIT 1', {
        ['@plate'] = cleanPlate
    }, function(results)
        -- Initialize default empty trunk
        local trunkData = {
            items = {},
            weight = 0,
            owner = identifier, -- Set current player as owner for new trunks
            shared = 0
        }
        
        -- If trunk exists in database
        if results and #results > 0 then
            local dbTrunk = results[1]
            local trunkOwner = dbTrunk.owner
            local isShared = dbTrunk.shared == 1
            
            -- Try to parse existing data
            if dbTrunk.data then
                local parsedData = json.decode(dbTrunk.data)
                if parsedData then
                    trunkData.items = parsedData.items or {}
                    trunkData.weight = parsedData.weight or 0
                end
            end
            
            -- Check if player has access to this trunk
            local hasAccess = false
            
            -- Job-based access (police, etc.)
            if Config.JobAccess[job] then
                if Config.Debug then print("^2[ESX_TRUNK] Access granted via job: " .. job .. "^0") end
                hasAccess = true
            -- Owner-based access
            elseif trunkOwner and trunkOwner == identifier then
                if Config.Debug then print("^2[ESX_TRUNK] Access granted as owner^0") end
                hasAccess = true
            -- Shared trunk access
            elseif isShared then
                if Config.Debug then print("^2[ESX_TRUNK] Access granted via shared status^0") end
                hasAccess = true
            -- No access - create a new trunk record for this player
            else
                if Config.Debug then print("^1[ESX_TRUNK] No access to existing trunk^0") end
                
                -- Update trunk ownership to current player
                if Config.AutoClaimUnownedTrunks and (trunkOwner == nil or trunkOwner == '') then
                    MySQL.Async.execute('UPDATE trunk_inventory SET owner = @owner WHERE id = @id', {
                        ['@owner'] = identifier,
                        ['@id'] = dbTrunk.id
                    })
                    
                    if Config.Debug then print("^2[ESX_TRUNK] Updated trunk ownership to current player^0") end
                    hasAccess = true
                    trunkData.owner = identifier
                else
                    -- Report access denied
                    if Config.Debug then print("^1[ESX_TRUNK] Access denied to trunk^0") end
                    
                    -- Notify player
                    if Config.ShowAccessDenied then
                        TriggerClientEvent('esx:showNotification', source, "You don't have access to this trunk")
                    end
                    
                    -- Return nil to indicate access denied
                    cb(nil)
                    return
                end
            end
            
        -- Trunk doesn't exist yet - create it
        -- Trunk doesn't exist yet - check if we should create it
else
    if Config.Debug then print("^3[ESX_TRUNK] Trunk doesn't exist - checking ownership^0") end
    
    -- Check if this is a vehicle in the owned_vehicles table
    MySQL.Async.fetchScalar('SELECT COUNT(*) FROM owned_vehicles WHERE REPLACE(UPPER(plate), " ", "") = @plate', {
        ['@plate'] = cleanPlate
    }, function(count)
        if count > 0 or Config.AllowNonOwnedVehicles then
            -- Vehicle exists in owned_vehicles or we're allowing trunks for unowned vehicles
            MySQL.Async.execute('INSERT INTO trunk_inventory (plate, owner, shared, data) VALUES (@plate, @owner, @shared, @data)', {
                ['@plate'] = cleanPlate,
                ['@owner'] = identifier,
                ['@shared'] = 0,
                ['@data'] = json.encode({items = {}, weight = 0})
            })
            
            if Config.Debug then print("^2[ESX_TRUNK] Created new trunk record with owner: " .. identifier .. "^0") end
            
            -- Return the trunk data to client
            trunkData.plate = plate
            cb(trunkData)
        else
            -- Vehicle does not exist in owned_vehicles and we're not allowing trunks for unowned vehicles
            if Config.Debug then print("^1[ESX_TRUNK] Vehicle not found in owned_vehicles table, denying trunk access^0") end
            
            if Config.ShowAccessDenied then
                TriggerClientEvent('esx:showNotification', source, "This vehicle has no trunk storage available")
            end
            
            -- Return nil to indicate access denied
            cb(nil)
        end
    end)
    return -- Important: Return here to prevent executing the code below
end
        
        -- For debugging, ensure plate is included in the returned data
        trunkData.plate = plate
        
        -- Return the trunk data to client
        cb(trunkData)
    end)
end)

-- Debug ownership callback for client
ESX.RegisterServerCallback('esx_trunk:debugOwnership', function(source, cb, plate, modelName)
    -- Ensure Trunks is initialized
    if Trunks == nil then
        Trunks = {}
        print("^3[ESX_TRUNK] Warning: Trunks table was nil during debugOwnership, initialized empty table^0")
    end
    
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.getIdentifier()
    local job = xPlayer.getJob().name
    local result = {
        hasAccess = false,
        reason = "Unknown error"
    }
    
    -- Debug header
    print("^2[ESX_TRUNK DEBUG] === Ownership Debug ===^0")
    print("^2[ESX_TRUNK DEBUG] Player: " .. GetPlayerName(source) .. "^0")
    print("^2[ESX_TRUNK DEBUG] Identifier: " .. identifier .. "^0")
    print("^2[ESX_TRUNK DEBUG] Job: " .. job .. "^0")
    print("^2[ESX_TRUNK DEBUG] Plate: " .. tostring(plate) .. "^0")
    print("^2[ESX_TRUNK DEBUG] Model: " .. (modelName or "unknown") .. "^0")
    
    -- 1. Job Access Check
    if Config.JobAccess[job] then
        result.hasAccess = true
        result.reason = "Access granted due to job: " .. job
        cb(result)
        return
    end
    
    -- Clean plate for database check
    local cleanPlate = CleanPlate(plate or "UNKNOWN")
    
    -- 2. Job Vehicle Check
    if string.match(cleanPlate, "^WORK") then
        local jobCode = string.match(cleanPlate, "^WORK(%w+)")
        if jobCode and Config.JobVehicleTypes[jobCode] then
            local vehicleJobType = Config.JobVehicleTypes[jobCode]
            
            if job == vehicleJobType then
                result.hasAccess = true
                result.reason = "Access granted as " .. vehicleJobType .. " for job vehicle"
                cb(result)
                return
            else
                result.hasAccess = false
                result.reason = "You need to be a " .. vehicleJobType .. " to access this vehicle"
                cb(result)
                return
            end
        end
    end
    
    -- 3. Police Vehicle Check
    if modelName and Config.PoliceVehicles[modelName] then
        if job == 'police' then
            result.hasAccess = true
            result.reason = "Police officer accessing police vehicle"
        else
            result.hasAccess = false
            result.reason = "Only police can access police vehicles"
        end
        cb(result)
        return
    end
    
    -- 4. Database Ownership check
    MySQL.Async.fetchAll('SELECT * FROM trunk_inventory WHERE REPLACE(UPPER(plate), " ", "") = @plate LIMIT 1', {
        ['@plate'] = cleanPlate
    }, function(results)
        -- Print raw database results
        print("^2[ESX_TRUNK DEBUG] Database query results:^0")
        if results and #results > 0 then
            for i, row in ipairs(results) do
                print("^2[ESX_TRUNK DEBUG] Result " .. i .. ", Owner: " .. (row.owner or "none") .. "^0")
                print("^2[ESX_TRUNK DEBUG] Shared: " .. row.shared .. "^0")
            end
            
            local trunk = results[1]
            
            -- Owner check
            if trunk.owner == identifier then
                result.hasAccess = true
                result.reason = "You are the owner of this trunk"
            -- Shared check
            elseif trunk.shared == 1 then
                result.hasAccess = true
                result.reason = "This is a shared trunk"
            -- No access
            else
                result.hasAccess = false
                result.reason = "Trunk belongs to another player. DB Owner: " .. (trunk.owner or "none")
            end
        else
            print("^2[ESX_TRUNK DEBUG] No results found in database^0")
            
            -- Trunk doesn't exist
            if Config.AllowNonOwnedVehicles then
                result.hasAccess = true
                result.reason = "New trunk will be created for you"
            else
                result.hasAccess = false
                result.reason = "Vehicle not found in trunk database"
            end
        end
        
        cb(result)
    end)
end)

-- Callback to get player inventory (if needed)
ESX.RegisterServerCallback('esx_trunk:getPlayerInventory', function(source, cb)
    -- Ensure Trunks is initialized
    if Trunks == nil then
        Trunks = {}
        print("^3[ESX_TRUNK] Warning: Trunks table was nil during getPlayerInventory, initialized empty table^0")
    end
    
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then
        cb({})
        return
    end
    
    local items = xPlayer.getInventory()
    local playerItems = {}
    
    for i=1, #items do
        local item = items[i]
        
        if item.count > 0 then
            table.insert(playerItems, {
                name = item.name,
                count = item.count,
                label = item.label
            })
        end
    end
    
    cb(playerItems)
end)

-- Add item to trunk
RegisterNetEvent('esx_trunk:addItem')
AddEventHandler('esx_trunk:addItem', function(plate, item, count)
    -- Ensure Trunks is initialized
    if Trunks == nil then
        Trunks = {}
        print("^3[ESX_TRUNK] Warning: Trunks table was nil during addItem, initialized empty table^0")
    end
    
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    
    if not xPlayer then return end
    
    -- Debug info for troubleshooting
    if Config.Debug then
        print("^3[DEBUG] Add Item Request - Plate: " .. tostring(plate) .. "^0")
        print("^3[DEBUG] Add Item Request - Type: " .. type(plate) .. "^0")
        print("^3[DEBUG] Add Item Request - Item: " .. tostring(item) .. "^0")
        print("^3[DEBUG] Add Item Request - Count: " .. tostring(count) .. "^0")
    end
    
    -- Check if count is valid
    if not count or count <= 0 then
        xPlayer.showNotification("Invalid quantity")
        return
    end
    
    -- Check if plate is valid
    if not plate then
        if Config.Debug then
            print("^1[ERROR] Attempted to add item to nil plate^0")
        end
        xPlayer.showNotification("Invalid vehicle")
        return
    end
    
    -- Check if item is blacklisted
    if IsItemBlacklisted(item) then
        xPlayer.showNotification("This item cannot be stored in vehicle trunks")
        return
    end
    
    -- Get player item data
    local xItem = xPlayer.getInventoryItem(item)
    
    if not xItem then
        xPlayer.showNotification("Invalid item")
        return
    end
    
    if count > xItem.count then
        xPlayer.showNotification("You don't have enough of this item")
        return
    end
    
    -- Clean plate for consistency
    local cleanPlate = CleanPlate(plate)
    
    -- Check if trunk exists in memory
    if not Trunks[cleanPlate] then
        if Config.Debug then
            print("^3[DEBUG] Trunk not in memory, loading from database: " .. cleanPlate .. "^0")
        end
        
        MySQL.Async.fetchAll('SELECT * FROM trunk_inventory WHERE REPLACE(UPPER(plate), " ", "") = @plate LIMIT 1', {
            ['@plate'] = cleanPlate
        }, function(results)
            if results and #results > 0 then
                -- Initialize from database
                local data = json.decode(results[1].data) or {items = {}, weight = 0}
                Trunks[cleanPlate] = {
                    items = data.items or {},
                    weight = data.weight or 0,
                    owner = results[1].owner,
                    shared = results[1].shared
                }
                
                if Config.Debug then
                    print("^2[DEBUG] Loaded trunk from database: " .. cleanPlate .. "^0")
                end
                
                -- Now proceed with adding the item
                AddItemToTrunk(_source, cleanPlate, item, count)
            else
                -- Create new trunk
                Trunks[cleanPlate] = {
                    items = {},
                    weight = 0,
                    owner = xPlayer.getIdentifier(),
                    shared = 0
                }
                
                -- Save to database
                MySQL.Async.execute('INSERT INTO trunk_inventory (plate, owner, shared, data) VALUES (@plate, @owner, @shared, @data)', {
                    ['@plate'] = cleanPlate,
                    ['@owner'] = xPlayer.getIdentifier(),
                    ['@shared'] = 0,
                    ['@data'] = json.encode({items = {}, weight = 0})
                })
                
                if Config.Debug then
                    print("^2[DEBUG] Created new trunk in database: " .. cleanPlate .. "^0")
                end
                
                -- Now proceed with adding the item
                AddItemToTrunk(_source, cleanPlate, item, count)
            end
        end)
    else
        -- Trunk exists in memory, proceed with adding item
        if Config.Debug then
            print("^2[DEBUG] Trunk exists in memory, adding item directly: " .. cleanPlate .. "^0")
        end
        
        AddItemToTrunk(_source, cleanPlate, item, count)
    end
end)


-- Helper function to add item to trunk
function AddItemToTrunk(source, plate, item, count)
    -- Ensure Trunks is initialized
    if Trunks == nil then
        Trunks = {}
        print("^3[ESX_TRUNK] Warning: Trunks table was nil during AddItemToTrunk, initialized empty table^0")
    end
    
    local xPlayer = ESX.GetPlayerFromId(source)
    
    -- Additional safety checks
    if not xPlayer then
        print("^1[ERROR] Player not found in AddItemToTrunk^0")
        return
    end
    
    if not plate then
        print("^1[ERROR] Plate is nil in AddItemToTrunk^0")
        return
    end
    
    if not Trunks[plate] then
        print("^1[ERROR] Trunk not found for plate in AddItemToTrunk: " .. tostring(plate) .. "^0")
        xPlayer.showNotification("Error adding item: trunk not found")
        return
    end
    
    -- Calculate item weight
    local itemWeight = 0
    
    -- Safe check for ESX.Items or item weights
    if ESX.Items and ESX.Items[item] and ESX.Items[item].weight then
        itemWeight = ESX.Items[item].weight * count
    else
        itemWeight = 1 * count -- Default weight
    end
    
    if Config.Debug then
        print("^3[ESX_TRUNK] Adding item to trunk: " .. item .. " x" .. count .. " (Weight: " .. itemWeight .. ")^0")
    end
    
    -- Make sure items array exists
    if Trunks[plate].items == nil then
        Trunks[plate].items = {}
    end
    
    -- Add item to trunk
    local found = false
    for i=1, #Trunks[plate].items do
        if Trunks[plate].items[i].name == item then
            Trunks[plate].items[i].count = Trunks[plate].items[i].count + count
            found = true
            break
        end
    end
    
    if not found then
        local itemLabel = item
        
        -- Safe check for item label
        if ESX.Items and ESX.Items[item] and ESX.Items[item].label then
            itemLabel = ESX.Items[item].label
        else
            -- Try to get the label from player's inventory item
            local xItem = xPlayer.getInventoryItem(item)
            if xItem and xItem.label then
                itemLabel = xItem.label
            end
        end
        
        table.insert(Trunks[plate].items, {
            name = item,
            count = count,
            label = itemLabel
        })
    end
    
    -- Update weight
    if Trunks[plate].weight == nil then
        Trunks[plate].weight = 0
    end
    Trunks[plate].weight = Trunks[plate].weight + itemWeight
    
    -- Remove from player inventory
    xPlayer.removeInventoryItem(item, count)
    
    -- Save to database
    SaveTrunkInventory(plate, Trunks[plate])
    
    -- IMPORTANT: Add plate to the data we're sending back to client for refresh
    if not Trunks[plate].plate then
        Trunks[plate].plate = plate
    end
    
    -- Refresh inventory for player
    TriggerClientEvent('esx_trunk:refreshInventory', source, Trunks[plate], plate)
    
    if Config.Debug then
        print("^2[ESX_TRUNK] Item added successfully^0")
    end
end

-- UPDATED SaveTrunkInventory function to handle data properly
function SaveTrunkInventory(plate, data)
    -- Ensure Trunks is initialized
    if Trunks == nil then
        Trunks = {}
        print("^3[ESX_TRUNK] Warning: Trunks table was nil during SaveTrunkInventory, initialized empty table^0")
    end
    
    -- Check for nil plate
    if plate == nil then
        if Config.Debug then
            print("^1[ERROR] Attempted to save trunk data with nil plate^0")
        end
        return
    end
    
    -- Prepare data for saving - we don't want to save the plate in the data JSON
    local saveData = {
        items = data.items or {},
        weight = data.weight or 0
    }
    
    -- Make sure plate is clean
    local cleanPlate = string.gsub(plate, "%s", ""):upper()
    
    -- Save to database
    MySQL.Async.execute('UPDATE trunk_inventory SET data = @data WHERE REPLACE(UPPER(plate), " ", "") = @plate', {
        ['@plate'] = cleanPlate,
        ['@data'] = json.encode(saveData)
    })
    
    -- Update in-memory data with plate for client usage
    if Trunks[cleanPlate] then
        Trunks[cleanPlate].plate = plate
    end
    
    if Config.Debug then
        print("^2[ESX_TRUNK] Saved trunk data for plate " .. plate .. "^0")
    end
end

-- Remove item from trunk
RegisterNetEvent('esx_trunk:removeItem')
AddEventHandler('esx_trunk:removeItem', function(plate, item, count)
    -- Ensure Trunks is initialized
    if Trunks == nil then
        Trunks = {}
        print("^3[ESX_TRUNK] Warning: Trunks table was nil during removeItem, initialized empty table^0")
    end
    
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    
    if not xPlayer then return end
    
    -- Check if count is valid
    if not count or count <= 0 then
        xPlayer.showNotification("Invalid quantity")
        return
    end
    
    -- Check if plate is valid
    if not plate then
        if Config.Debug then
            print("^1[ERROR] Attempted to remove item from nil plate^0")
        end
        xPlayer.showNotification("Invalid vehicle")
        return
    end
    
    -- Clean plate for consistency
    local cleanPlate = CleanPlate(plate)
    
    -- Check if trunk exists
    if not Trunks[cleanPlate] then
        xPlayer.showNotification("This vehicle trunk is empty")
        return
    end
    
    -- Find item in trunk
    local found = false
    local itemIndex = 0
    
    for i=1, #Trunks[cleanPlate].items do
        if Trunks[cleanPlate].items[i].name == item then
            found = true
            itemIndex = i
            break
        end
    end
    
    if not found then
        xPlayer.showNotification("This item is not in the trunk")
        return
    end
    
    -- Check if enough items in trunk
    if Trunks[cleanPlate].items[itemIndex].count < count then
        xPlayer.showNotification("There are not enough of this item in the trunk")
        return
    end
    
    -- Check if player can carry the item
    if not xPlayer.canCarryItem(item, count) then
        xPlayer.showNotification("You cannot carry that much weight")
        return
    end
    
    -- Calculate item weight
    local itemWeight = 0
    
    -- Safe check for ESX.Items or item weights
    if ESX.Items and ESX.Items[item] and ESX.Items[item].weight then
        itemWeight = ESX.Items[item].weight * count
    else
        itemWeight = 1 * count -- Default weight
    end
    
    if Config.Debug then
        print("^3[ESX_TRUNK] Removing item from trunk: " .. item .. " x" .. count .. " (Weight: " .. itemWeight .. ")^0")
    end
    
    -- Update trunk inventory
    Trunks[cleanPlate].items[itemIndex].count = Trunks[cleanPlate].items[itemIndex].count - count
    
    -- Update weight
    Trunks[cleanPlate].weight = Trunks[cleanPlate].weight - itemWeight
    
    -- Remove item if count reaches 0
    if Trunks[cleanPlate].items[itemIndex].count <= 0 then
        table.remove(Trunks[cleanPlate].items, itemIndex)
    end
    
    -- Add to player inventory
    xPlayer.addInventoryItem(item, count)
    
    -- Save to database
    SaveTrunkInventory(cleanPlate, Trunks[cleanPlate])
    
    -- Refresh inventory for player
    TriggerClientEvent('esx_trunk:refreshInventory', source, Trunks[cleanPlate], cleanPlate)
    
    if Config.Debug then
        print("^2[ESX_TRUNK] Item removed successfully^0")
    end
end)

-- Event to handle trunk refreshes
RegisterNetEvent('esx_trunk:requestRefresh')
AddEventHandler('esx_trunk:requestRefresh', function(plate)
    -- Ensure Trunks is initialized
    if Trunks == nil then
        Trunks = {}
        print("^3[ESX_TRUNK] Warning: Trunks table was nil during requestRefresh, initialized empty table^0")
    end
    
    local _source = source
    
    -- Clean plate for consistency
    local cleanPlate = CleanPlate(plate or "UNKNOWN")
    
    if Trunks[cleanPlate] then
        TriggerClientEvent('esx_trunk:refreshInventory', _source, Trunks[cleanPlate], cleanPlate)
    end
end)

-- Event for vehicle purchase integration
RegisterNetEvent('esx_vehicleshop:setVehicleOwned')
AddEventHandler('esx_vehicleshop:setVehicleOwned', function(vehicleProps)
    -- Ensure Trunks is initialized
    if Trunks == nil then
        Trunks = {}
        print("^3[ESX_TRUNK] Warning: Trunks table was nil during setVehicleOwned, initialized empty table^0")
    end
    
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    
    -- Make sure we have the necessary data
    if not vehicleProps or not vehicleProps.plate then
        print("^1[ERROR] Vehicle properties or plate missing in esx_vehicleshop:setVehicleOwned^0")
        return
    end
    
    -- Create trunk inventory record for the new vehicle
    CreateVehicleTrunkRecord(vehicleProps.plate, xPlayer.getIdentifier())
end)

-- Event to remove lockpick after failed attempt
RegisterNetEvent('esx_trunk:removeLockpick')
AddEventHandler('esx_trunk:removeLockpick', function()
    -- Ensure Trunks is initialized
    if Trunks == nil then
        Trunks = {}
        print("^3[ESX_TRUNK] Warning: Trunks table was nil during removeLockpick, initialized empty table^0")
    end
    
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer and Config.LockpickItem then
        xPlayer.removeInventoryItem(Config.LockpickItem, 1)
    end
end)

-- Log trunk reset for admin monitoring
RegisterNetEvent('esx_trunk:logReset')
AddEventHandler('esx_trunk:logReset', function()
    -- Ensure Trunks is initialized
    if Trunks == nil then
        Trunks = {}
        print("^3[ESX_TRUNK] Warning: Trunks table was nil during logReset, initialized empty table^0")
    end
    
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    local identifier = xPlayer.getIdentifier()
    local name = GetPlayerName(source)
    
    print("^3[ESX_TRUNK] Player " .. name .. " (" .. identifier .. ") used resettrunk command^0")
end)