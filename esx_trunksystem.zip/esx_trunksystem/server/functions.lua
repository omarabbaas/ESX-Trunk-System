-- Save trunk inventory to database
function SaveTrunkInventory(plate, data)
    local cleanPlate = string.gsub(plate, "%s", ""):upper()
    
    MySQL.Async.execute('UPDATE trunk_inventory SET data = @data WHERE REPLACE(UPPER(plate), " ", "") = @plate', {
        ['@plate'] = cleanPlate,
        ['@data'] = json.encode(data)
    })
    
    if Config.Debug then
        print("^2[ESX_TRUNK] Saved trunk data for plate " .. plate .. "^0")
    end
end

-- Check if item is blacklisted
function IsItemBlacklisted(item)
    for i=1, #Config.BlacklistedItems, 1 do
        if Config.BlacklistedItems[i] == item then
            return true
        end
    end
    
    return false
end

-- Calculate total weight of items
function CalculateTrunkWeight(items)
    local weight = 0
    
    for i=1, #items, 1 do
        local itemWeight = 1 -- Default weight
        local itemCount = items[i].count or 1
        
        -- Safe check for ESX.Items or item weights
        if ESX.Items then
            if ESX.Items[items[i].name] then
                if ESX.Items[items[i].name].weight then
                    itemWeight = ESX.Items[items[i].name].weight
                end
            end
        end
        
        weight = weight + (itemWeight * itemCount)
    end
    
    return weight
end

-- Clear trunk inventory
function ClearTrunkInventory(plate)
    if Trunks[plate] then
        Trunks[plate] = {
            items = {},
            weight = 0
        }
        
        SaveTrunkInventory(plate)
        return true
    else
        return false
    end
end

-- Get player access level for trunk
function GetTrunkAccessLevel(source, plate, modelName)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.getIdentifier()
    local job = xPlayer.getJob().name
    local cleanPlate = string.gsub(plate, "%s", ""):upper()
    
    -- Job-based access check (police, etc.)
    if Config.JobAccess[job] then
        if Config.Debug then 
            print("^2[ESX_TRUNK] Player has job access: " .. job .. "^0") 
        end
        return "full"
    end
    
    -- Check if it's a job vehicle (WORK prefix)
    if string.match(cleanPlate, "^WORK") then
        local jobCode = string.match(cleanPlate, "^WORK(%w+)")
        if jobCode and Config.JobVehicleTypes[jobCode] then
            local vehicleJobType = Config.JobVehicleTypes[jobCode]
            
            -- Check if player's job matches the vehicle job type
            if job == vehicleJobType then
                if Config.Debug then 
                    print("^2[ESX_TRUNK] Job vehicle access granted^0") 
                end
                return "job"
            else
                if Config.Debug then 
                    print("^1[ESX_TRUNK] Job vehicle access denied^0") 
                end
                return "none"
            end
        end
    end
    
    -- Check for police vehicle access
    if modelName and Config.PoliceVehicles[modelName] then
        if job == 'police' then
            if Config.Debug then 
                print("^2[ESX_TRUNK] Police vehicle access granted^0") 
            end
            return "police"
        else
            if Config.Debug then 
                print("^1[ESX_TRUNK] Police vehicle access denied^0") 
            end
            return "none"
        end
    end
    
    -- Get trunk record
    local result = MySQL.Sync.fetchAll('SELECT owner, shared FROM trunk_inventory WHERE REPLACE(UPPER(plate), " ", "") = @plate LIMIT 1', {
        ['@plate'] = cleanPlate
    })
    
    if result and #result > 0 then
        local trunk = result[1]
        
        -- Check if player is the owner
        if trunk.owner == identifier then
            if Config.Debug then 
                print("^2[ESX_TRUNK] Owner access granted^0") 
            end
            return "owner"
        end
        
        -- Check if trunk is shared
        if trunk.shared == 1 then
            if Config.Debug then 
                print("^2[ESX_TRUNK] Shared trunk access granted^0") 
            end
            return "shared"
        end
        
        -- No access
        if Config.Debug then 
            print("^1[ESX_TRUNK] No access to trunk^0") 
        end
        return "none"
    else
        -- Trunk doesn't exist yet
        if Config.AllowNonOwnedVehicles then
            if Config.Debug then 
                print("^2[ESX_TRUNK] New trunk access granted^0") 
            end
            return "new"
        else
            if Config.Debug then 
                print("^1[ESX_TRUNK] Non-owned vehicle access denied^0") 
            end
            return "none"
        end
    end
end

-- Function to determine job type from work vehicle plate
function GetJobVehicleType(plate)
    -- Remove 'WORK' prefix and extract job type
    local jobCode = string.match(plate, "^WORK(%w+)")
    
    if not jobCode then return nil end
    
    -- Return the job type if found in config, otherwise nil
    return Config.JobVehicleTypes[jobCode]
end

-- Function to get or create a shared job trunk
function GetOrCreateJobTrunk(plate, jobType, cb)
    local cleanPlate = string.gsub(plate, "%s", ""):upper()
    
    -- Check if job trunk already exists
    MySQL.Async.fetchAll('SELECT * FROM trunk_inventory WHERE REPLACE(UPPER(plate), " ", "") = @plate LIMIT 1', {
        ['@plate'] = cleanPlate
    }, function(results)
        local trunkData = {
            items = {},
            weight = 0,
            owner = "job_" .. jobType, -- Special owner identifier for job vehicles
            shared = 1,                -- Job trunks are always shared
            isJobTrunk = true,         -- Flag to identify job trunks in client
            jobType = jobType          -- Store the job type
        }
        
        -- If trunk exists, use existing data
        if results and #results > 0 then
            local dbTrunk = results[1]
            
            -- Try to parse existing data
            if dbTrunk.data then
                local parsedData = json.decode(dbTrunk.data)
                if parsedData then
                    trunkData.items = parsedData.items or {}
                    trunkData.weight = parsedData.weight or 0
                end
            end
            
            -- Update owner and shared status if needed
            if dbTrunk.owner ~= "job_" .. jobType or dbTrunk.shared ~= 1 then
                MySQL.Async.execute('UPDATE trunk_inventory SET owner = @owner, shared = 1 WHERE id = @id', {
                    ['@owner'] = "job_" .. jobType,
                    ['@id'] = dbTrunk.id
                })
                
                if Config.Debug then
                    print("^3[ESX_TRUNK] Updated job trunk metadata^0")
                end
            end
        else
            -- Create new job trunk
            MySQL.Async.execute('INSERT INTO trunk_inventory (plate, owner, shared, data) VALUES (@plate, @owner, 1, @data)', {
                ['@plate'] = cleanPlate,
                ['@owner'] = "job_" .. jobType,
                ['@data'] = json.encode({items = {}, weight = 0})
            })
            
            if Config.Debug then
                print("^2[ESX_TRUNK] Created new job trunk for " .. jobType .. "^0")
            end
        end
        
        -- Return the trunk data
        if cb then
            cb(trunkData)
        end
    end)
end

-- Create trunk inventory record for a new vehicle
function CreateVehicleTrunkRecord(plate, owner)
    -- Clean the plate for consistency
    local cleanPlate = string.gsub(plate, "%s", ""):upper()
    
    -- Check if a trunk record already exists for this plate
    MySQL.Async.fetchScalar('SELECT COUNT(*) FROM trunk_inventory WHERE REPLACE(UPPER(plate), " ", "") = @plate', {
        ['@plate'] = cleanPlate
    }, function(count)
        if count > 0 then
            if Config.Debug then
                print("^3[ESX_TRUNK] Trunk record already exists for plate: " .. plate .. "^0")
            end
            return
        end
        
        -- Create new trunk record with the vehicle owner
        MySQL.Async.execute('INSERT INTO trunk_inventory (plate, owner, shared, data) VALUES (@plate, @owner, @shared, @data)', {
            ['@plate'] = cleanPlate,
            ['@owner'] = owner,
            ['@shared'] = 0, -- Not shared by default
            ['@data'] = json.encode({items = {}, weight = 0})
        })
        
        if Config.Debug then
            print("^2[ESX_TRUNK] Created trunk record for new vehicle^0")
            print("^2[ESX_TRUNK] Plate: " .. plate .. ", Owner: " .. owner .. "^0")
        end
    end)
end