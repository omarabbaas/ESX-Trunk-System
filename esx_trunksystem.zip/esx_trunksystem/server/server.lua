ESX = exports["es_extended"]:getSharedObject()
Trunks = {} -- Global table to store trunk data

-- Initialize trunks when server starts
MySQL.ready(function()
    if Config.Debug then
        print("^2[ESX_TRUNK] MySQL is ready, loading trunk data^0")
    end
    
    -- Load all saved trunks from database
    MySQL.Async.fetchAll('SELECT * FROM trunk_inventory', {}, function(results)
        if results and #results > 0 then
            for i=1, #results, 1 do
                local plate = results[i].plate
                local data = json.decode(results[i].data)
                
                if data then
                    Trunks[plate] = {
                        items = data.items or {},
                        weight = data.weight or 0,
                        owner = results[i].owner,
                        shared = results[i].shared
                    }
                else
                    Trunks[plate] = {
                        items = {},
                        weight = 0,
                        owner = results[i].owner,
                        shared = results[i].shared
                    }
                end
            end
            
            print("^2[ESX_TRUNK] Loaded " .. #results .. " vehicle trunks from database^0")
        else
            print("^3[ESX_TRUNK] No trunk data found in database^0")
            Trunks = {} -- Initialize as empty table
        end
    end)
    
    -- Create database table if it doesn't exist
    MySQL.Async.execute([[
        CREATE TABLE IF NOT EXISTS `trunk_inventory` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `plate` varchar(8) NOT NULL,
            `owner` varchar(60) DEFAULT NULL,
            `shared` tinyint(1) NOT NULL DEFAULT 0,
            `data` longtext DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `plate` (`plate`),
            KEY `owner` (`owner`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]], {}, function(rowsChanged)
        if Config.Debug then
            print("^2[ESX_TRUNK] Database table check completed^0")
        end
    end)
end)

-- Register command to link with vehicle shop (optional)
RegisterCommand('integratetrunks', function(source, args, rawCommand)
    local xPlayer = nil
    if source > 0 then
        xPlayer = ESX.GetPlayerFromId(source)
        if not xPlayer.getGroup() == 'admin' then
            return
        end
    end
    
    print("^3[ESX_TRUNK] Starting trunk integration for existing vehicles...^0")
    
    MySQL.Async.fetchAll('SELECT plate, owner FROM owned_vehicles', {}, function(vehicles)
        if not vehicles or #vehicles == 0 then
            print("^3[ESX_TRUNK] No vehicles found in database^0")
            if xPlayer then xPlayer.showNotification("No vehicles found in database") end
            return
        end
        
        local created = 0
        
        for _, vehicle in ipairs(vehicles) do
            -- Check if trunk record exists
            local cleanPlate = string.gsub(vehicle.plate, "%s", ""):upper()
            
            MySQL.Async.fetchScalar('SELECT COUNT(*) FROM trunk_inventory WHERE REPLACE(UPPER(plate), " ", "") = @plate', {
                ['@plate'] = cleanPlate
            }, function(count)
                if count == 0 then
                    -- Create trunk record
                    MySQL.Async.execute('INSERT INTO trunk_inventory (plate, owner, shared, data) VALUES (@plate, @owner, @shared, @data)', {
                        ['@plate'] = cleanPlate,
                        ['@owner'] = vehicle.owner,
                        ['@shared'] = 0,
                        ['@data'] = json.encode({items = {}, weight = 0})
                    })
                    
                    created = created + 1
                    
                    if Config.Debug then
                        print("^2[ESX_TRUNK] Created trunk record for existing vehicle^0")
                        print("^2[ESX_TRUNK] Plate: " .. vehicle.plate .. ", Owner: " .. vehicle.owner .. "^0")
                    end
                end
            end)
            
            -- Small delay to prevent database overload
            Wait(10)
        end
        
        if source > 0 then
            TriggerClientEvent('esx:showNotification', source, "Created " .. created .. " trunk records")
        end
        
        print("^2[ESX_TRUNK] Created " .. created .. " trunk records for existing vehicles^0")
    end)
end, true)