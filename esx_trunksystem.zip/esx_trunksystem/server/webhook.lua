-- Discord Webhook Integration (Optional)
-- This file shows how you can integrate Discord webhooks to monitor trunk usage and issues

-- Configure your Discord webhook URL in config.lua
-- Example: Config.DiscordWebhook = "https://discord.com/api/webhooks/your-webhook-url"

-- Function to send messages to Discord
function SendToDiscord(name, message, color)
    -- Skip if webhook not configured
    if not Config.UseDiscordLogs or not Config.DiscordWebhook then
        return
    end
    
    -- Prepare the webhook payload
    local embed = {
        {
            ["color"] = color,
            ["title"] = "**" .. name .. "**",
            ["description"] = message,
            ["footer"] = {
                ["text"] = "ESX Trunk System • " .. os.date("%Y-%m-%d %H:%M:%S"),
            },
        }
    }
    
    -- Send the webhook
    PerformHttpRequest(Config.DiscordWebhook, function(err, text, headers) end, 'POST', json.encode({embeds = embed}), { ['Content-Type'] = 'application/json' })
end

-- Example usage for trunk reset logging
RegisterServerEvent('esx_trunk:logResetToDiscord')
AddEventHandler('esx_trunk:logResetToDiscord', function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    local identifier = xPlayer.getIdentifier()
    local name = GetPlayerName(source)
    
    -- Get player position for context
    local ped = GetPlayerPed(source)
    local coords = GetEntityCoords(ped)
    local positionInfo = "Position: " .. coords.x .. ", " .. coords.y .. ", " .. coords.z
    
    -- Log to Discord
    SendToDiscord(
        "Trunk System Reset",
        "Player: **" .. name .. "**\nIdentifier: `" .. identifier .. "`\n" .. positionInfo,
        16711680 -- Red color
    )
end)

-- Log trunk item transfers
RegisterServerEvent('esx_trunk:logItemTransfer')
AddEventHandler('esx_trunk:logItemTransfer', function(source, plate, item, count, action)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    local identifier = xPlayer.getIdentifier()
    local name = GetPlayerName(source)
    
    -- Only log high-value or suspiciously large transfers
    if count > 20 or (ESX.Items[item] and ESX.Items[item].rare) then
        SendToDiscord(
            "Trunk Item Transfer",
            "Player: **" .. name .. "**\nAction: " .. action .. "\nItem: " .. item .. "\nAmount: " .. count .. "\nVehicle: " .. plate,
            65280 -- Green color
        )
    end
end)